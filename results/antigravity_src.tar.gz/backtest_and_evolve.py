# -*- coding: utf-8 -*-
"""
Antigravity 自我演进核心：回测对比 + 策略进化报告
从 latest_decision.json 提取历史预测，与 data/lottery_history.csv 的真实开奖进行碰撞校对。
"""
import json
import os
import pandas as pd
from datetime import datetime
from pathlib import Path

# ─── 相对路径 ─────────────────────────────────────────────
_PROJECT_ROOT = Path(__file__).resolve().parent

DATA_FILE = _PROJECT_ROOT / "data" / "lottery_history.csv"
PRED_FILE = _PROJECT_ROOT / "latest_decision.json"
PRED_FILE_V2 = _PROJECT_ROOT / "latest_predictions_evolved.json"
PRED_FILE_ENHANCED = _PROJECT_ROOT / "latest_decision_enhanced.json"

df = pd.read_csv(str(DATA_FILE))

# 尝试多个预测文件格式
decision = None
for pf in [PRED_FILE_V2, PRED_FILE_ENHANCED, PRED_FILE]:
    if pf.exists():
        with open(pf, "r", encoding="utf-8") as f:
            decision = json.load(f)
        print(f">>> [回测引擎] 使用预测文件: {pf}")
        break

if decision is None:
    print(f"❌ 未找到任何预测文件: {PRED_FILE_V2.name}, {PRED_FILE_ENHANCED.name}, {PRED_FILE.name}")
    exit(1)

# 兼容多种期号字段名
target_period = int(decision.get("target_period", decision.get("period", 0)))
print(f">>> [回测引擎] 目标期号: {target_period}")

# ========== 2. 提取真实开奖 ==========
# 优先尝试 period 列（标准格式），然后 id（旧格式）
actual_row = df[df["period"] == target_period]
if actual_row.empty and "id" in df.columns:
    actual_row = df[df["id"] == target_period]

if actual_row.empty:
    print(f"❌ 数据库中无 {target_period} 期的开奖记录！")
    exit(1)

# 兼容多种列名格式
row = actual_row.iloc[0]
actual_reds = set()
actual_blue = None

# 尝试 r1-r6 格式
for col in ['r1', 'r2', 'r3', 'r4', 'r5', 'r6']:
    val = row.get(col)
    if val is not None:
        actual_reds.add(int(val))
if actual_reds:
    actual_blue = int(row.get('b', 0))
else:
    # 尝试 red/blue 格式
    red_str = str(row.get('red', ''))
    if red_str:
        actual_reds = set(int(x.strip()) for x in red_str.split(','))
    actual_blue = int(row.get('blue', 0))

print(f">>> [真实开奖] 红球: {sorted(actual_reds)} | 蓝球: {actual_blue}")

# ========== 3. 逐组碰撞校对 ==========
results = []
best_hit = 0
best_group = None

# 兼容多种预测格式
predictions = decision.get("predictions", decision.get("audit_report", []))
for entry in predictions:
    if isinstance(entry, dict):
        pred_reds = set(entry.get("reds", entry.get("红球", [])))
        pred_blue = int(entry.get("blue", entry.get("蓝球", 0)))
        model_name = entry.get("agent", entry.get("模型", "Unknown"))
        group_name = entry.get("组别", "N/A")
    else:
        continue

    red_hits = pred_reds & actual_reds
    blue_hit = (pred_blue == actual_blue)

    result = {
        "模型": model_name,
        "组别": group_name,
        "预测红球": sorted(pred_reds),
        "预测蓝球": pred_blue,
        "红球命中": sorted(red_hits),
        "红球命中数": len(red_hits),
        "蓝球命中": "OK" if blue_hit else "MISS",
    }
    results.append(result)

    total_score = len(red_hits) + (1 if blue_hit else 0)
    if total_score > best_hit:
        best_hit = total_score
        best_group = result

# ========== 4. 统计分析 ==========
total_groups = len(results)
if total_groups == 0:
    print("⚠️ 没有找到有效的预测数据")
else:
    avg_red_hits = sum(r["红球命中数"] for r in results) / total_groups
    blue_hit_count = sum(1 for r in results if r["蓝球命中"] == "OK")
    all_predicted_reds = []
    for r in results:
        all_predicted_reds.extend(r["预测红球"])

    from collections import Counter
    freq = Counter(all_predicted_reds)
    consensus_nums = {k: v for k, v in freq.items() if v >= 3}
    missed_actual = actual_reds - set(all_predicted_reds)

    # ========== 5. 生成演进报告 ==========
    report_lines = []
    report_lines.append(f"# Antigravity 自我演进复盘报告")
    report_lines.append(f"> **复盘时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    report_lines.append(f"> **目标期号**: {target_period}")
    report_lines.append(f"> **真实开奖**: 红球 `{sorted(actual_reds)}` | 蓝球 `{actual_blue}`")
    report_lines.append("")
    report_lines.append("---")
    report_lines.append("")
    report_lines.append("## 逐组校对结果")
    report_lines.append("")
    report_lines.append("| 模型 | 组别 | 预测红球 | 预测蓝球 | 红球命中 | 命中数 | 蓝球 |")
    report_lines.append("|------|------|----------|----------|----------|--------|------|")
    for r in results:
        report_lines.append(
            f"| {r['模型']} | {r['组别']} | {r['预测红球']} | {r['预测蓝球']} | {r['红球命中']} | **{r['红球命中数']}** | {r['蓝球命中']} |"
        )

    report_lines.append("")
    report_lines.append("## 统计摘要")
    report_lines.append(f"- **总预测组数**: {total_groups}")
    report_lines.append(f"- **红球平均命中**: {avg_red_hits:.1f} / 6")
    report_lines.append(f"- **蓝球命中组数**: {blue_hit_count} / {total_groups}")
    if best_group:
        report_lines.append(f"- **最佳表现组**: {best_group['模型']} {best_group['组别']} (红{best_group['红球命中数']}+蓝{best_group['蓝球命中']})")

    report_lines.append("")
    report_lines.append("## 模式洞察与演进方向")
    report_lines.append("")
    report_lines.append("### 共识号码 (>=3组预测)")
    if consensus_nums:
        for num, count in sorted(consensus_nums.items(), key=lambda x: -x[1]):
            hit_mark = "命中" if num in actual_reds else "未中"
            report_lines.append(f"- **{num}** -> 被 {count} 组预测 -> {hit_mark}")
    else:
        report_lines.append("- 无明显共识，模型间离散度过高")

    report_lines.append("")
    report_lines.append("### 盲区号码")
    if missed_actual:
        report_lines.append(f"- **{sorted(missed_actual)}** -> 所有模型全部漏判！")
    else:
        report_lines.append("- 无盲区，所有真实号码至少被1组覆盖")

    report_lines.append("")
    report_lines.append("## 自我演进策略建议")
    if avg_red_hits < 1.5:
        report_lines.append("> 红球命中率极低，建议增加输入数据窗口。")
    elif avg_red_hits < 2.5:
        report_lines.append("> 红球命中率一般，建议引入连号/同尾检测模块。")
    else:
        report_lines.append("> 红球命中率较高，建议维持当前策略。")

    report = "\n".join(report_lines)
    output_path = _PROJECT_ROOT / "evolution_report.md"
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(report)

    print("\n" + "=" * 60)
    print(f"  复盘完成: {target_period} 期")
    print(f"  真实开奖: 红 {sorted(actual_reds)} | 蓝 {actual_blue}")
    print(f"  红球平均命中: {avg_red_hits:.1f} / 6")
    print(f"  蓝球命中组数: {blue_hit_count} / {total_groups}")
    if best_group:
        print(f"  最佳组: {best_group['模型']} {best_group['组别']}")
    print("=" * 60)
    print(f">>> 完整报告已生成: evolution_report.md")
