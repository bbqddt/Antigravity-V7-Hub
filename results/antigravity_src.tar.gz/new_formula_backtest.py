# -*- coding: utf-8 -*-
"""
新公式策略注入回测 V1.0

把公式开发生态生成的新公式注入到 enhanced_predictor 的策略池里，
跟原有9个策略做正式对比回测。
"""
import json
import random
import sys
import numpy as np
import pandas as pd
from pathlib import Path
from datetime import datetime

_PROJECT_ROOT = Path(__file__).resolve().parent

# 确保路径
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

from data_layer import load_history, Draw
from enhanced_predictor import (
    load_data, parse_reds, HotCoreStrategy, ColdStrikeStrategy,
    BalancedStrategy, ZoneControlStrategy, ConsecutiveStrategy,
    OmissionStrategy, TrendStrategy, AutocorrelationStrategy,
    CooccurrenceStrategy, WeightedEnsemble, predict_blue_omission,
    predict_blue_markov, predict_blue_balanced,
)
from formula_lang import get_default_primitives, FormulaGrammar


class NewFormulaStrategy:
    """将公式语言生成的公式包装成策略"""

    def __init__(self, formula, draws, name="new_formula"):
        self.formula = formula
        self.name = name
        self.draws = draws

    def generate(self):
        top6 = self.formula.rank_top_6(self.draws)
        return top6[:6]


def run_comparison_backtest():
    print("=" * 70)
    print("  新公式策略 vs 传统策略 — 正式对比回测")
    print("=" * 70)

    # 加载数据
    df = load_data()
    draws = load_history()

    # 1. 生成新公式
    print(f"\n[1] 生成新公式...")
    primitives = get_default_primitives()

    # 生成50个新公式
    new_formulas = []
    for i in range(50):
        n_prims = random.randint(2, 4)
        selected = random.sample(primitives, n_prims)
        op = random.choice(['resonance', 'cascade', 'phase_align', 'weighted_sum'])
        f = getattr(FormulaGrammar, op)(selected, name=f'inject_formula_{i}')
        new_formulas.append(f)

    print(f"    生成 {len(new_formulas)} 个新公式")

    # 2. 回测所有策略
    print(f"\n[2] 回测所有策略 (t-1预测t, 50轮预热 + 200轮回测)...")

    results = {}

    # 传统策略
    traditional = {
        "HotCore": HotCoreStrategy,
        "ColdStrike": ColdStrikeStrategy,
        "Balanced": BalancedStrategy,
        "ZoneControl": ZoneControlStrategy,
        "Consecutive": ConsecutiveStrategy,
        "Omission": OmissionStrategy,
        "Trend": TrendStrategy,
        "AutoCorr": AutocorrelationStrategy,
        "Cooccur": CooccurrenceStrategy,
    }

    for name, cls in traditional.items():
        total_hits = 0
        total_rounds = 0
        hits_per_round = []

        for i in range(50, min(250, len(df) - 1)):
            train_df = df.iloc[i:]
            test_draw = df.iloc[i - 1]
            temp_strategy = cls(train_df)
            actual_reds = set(parse_reds(test_draw))
            pred_reds = set(temp_strategy.generate())
            hit = len(actual_reds & pred_reds)
            total_hits += hit
            hits_per_round.append(hit)
            total_rounds += 1

        avg = total_hits / max(1, total_rounds)
        std = np.std(hits_per_round) if hits_per_round else 0
        results[f"[传统] {name}"] = {
            "avg_hits": round(avg, 4),
            "std": round(float(std), 4),
            "rounds": total_rounds,
            "max_hits": max(hits_per_round) if hits_per_round else 0,
        }

    # 新公式策略
    for i, formula in enumerate(new_formulas[:20]):  # 只回测前20个
        strat = NewFormulaStrategy(formula, draws, name=f"新公式_{i}")
        total_hits = 0
        total_rounds = 0
        hits_per_round = []

        for j in range(50, min(250, len(draws) - 1)):
            test_draw = draws[j - 1]
            actual_reds = set(test_draw.reds if hasattr(test_draw, 'reds') else sorted(list(test_draw.red)))
            pred_reds = set(strat.generate())
            hit = len(actual_reds & pred_reds)
            total_hits += hit
            hits_per_round.append(hit)
            total_rounds += 1

        avg = total_hits / max(1, total_rounds)
        std = np.std(hits_per_round) if hits_per_round else 0
        results[f"[新公式] {strat.name}"] = {
            "avg_hits": round(avg, 4),
            "std": round(float(std), 4),
            "rounds": total_rounds,
            "max_hits": max(hits_per_round) if hits_per_round else 0,
        }

    # 3. 排序
    sorted_results = sorted(results.items(), key=lambda x: -x[1]["avg_hits"])

    # 4. 输出
    print(f"\n{'='*70}")
    print(f"  回测结果排名 (平均红球命中数)")
    print(f"{'='*70}")

    traditional_results = {k: v for k, v in sorted_results if "[传统]" in k}
    new_formula_results = {k: v for k, v in sorted_results if "[新公式]" in k}

    print(f"\n  【传统策略】")
    for rank, (name, r) in enumerate(traditional_results.items(), 1):
        bar = "█" * int(r["avg_hits"] * 10)
        print(f"  #{rank:2d} {name:20s} {r['avg_hits']:.3f}/6 {bar}")

    print(f"\n  【新公式策略 Top-10】")
    for rank, (name, r) in enumerate(new_formula_results.items(), 1):
        bar = "█" * int(r["avg_hits"] * 10)
        print(f"  #{rank:2d} {name:20s} {r['avg_hits']:.3f}/6 {bar}")

    # 5. 统计对比
    trad_avg = np.mean([r["avg_hits"] for r in traditional_results.values()])
    trad_std = np.mean([r["std"] for r in traditional_results.values()])
    new_avg = np.mean([r["avg_hits"] for r in new_formula_results.values()])
    new_std = np.mean([r["std"] for r in new_formula_results.values()])

    print(f"\n{'='*70}")
    print(f"  统计对比")
    print(f"{'='*70}")
    print(f"  传统策略平均: {trad_avg:.3f}/6 (std={trad_std:.3f})")
    print(f"  新公式平均:   {new_avg:.3f}/6 (std={new_std:.3f})")
    print(f"  差异:         {new_avg - trad_avg:+.3f}/6")
    print(f"  理论随机基线: 1.09/6")

    # 6. 保存
    report = {
        "timestamp": datetime.now().isoformat(),
        "data_periods": len(df),
        "backtest_rounds": min(200, len(df) - 51),
        "traditional_avg": round(float(trad_avg), 4),
        "new_formula_avg": round(float(new_avg), 4),
        "difference": round(float(new_avg - trad_avg), 4),
        "random_baseline": 1.09,
        "all_results": results,
        "traditional_ranking": sorted(traditional_results.items(), key=lambda x: -x[1]["avg_hits"]),
        "new_formula_ranking": sorted(new_formula_results.items(), key=lambda x: -x[1]["avg_hits"]),
    }

    output_path = _PROJECT_ROOT / "new_formula_backtest_report.json"
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
    print(f"\n  报告已保存: {output_path}")

    return report


if __name__ == "__main__":
    run_comparison_backtest()
