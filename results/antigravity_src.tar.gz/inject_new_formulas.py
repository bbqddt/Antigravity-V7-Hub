# -*- coding: utf-8 -*-
"""
新公式注入增强引擎 V1.0

把回测中表现最好的新公式注入到 enhanced_predictor 的策略池里，
跟传统策略融合输出预测。
"""
import json
import random
import sys
import numpy as np
from pathlib import Path
from datetime import datetime

_PROJECT_ROOT = Path(__file__).resolve().parent
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

from data_layer import load_history, Draw
from enhanced_predictor import load_data, parse_reds
from formula_lang import get_default_primitives, FormulaGrammar


class NewFormulaStrategy:
    """将公式包装成策略"""

    def __init__(self, formula, draws, name="new_formula"):
        self.formula = formula
        self.name = name
        self.draws = draws

    def generate(self):
        return self.formula.rank_top_6(self.draws)[:6]


def inject_and_predict():
    print("=" * 70)
    print("  新公式注入增强引擎 — 融合预测")
    print("=" * 70)

    df = load_data()
    draws = load_history()
    latest_period = int(df.iloc[0]["period"])
    target_period = latest_period + 1

    # 1. 生成新公式
    print(f"\n[1] 生成新公式...")
    primitives = get_default_primitives()
    new_formulas = []
    for i in range(50):
        n_prims = random.randint(2, 4)
        selected = random.sample(primitives, n_prims)
        op = random.choice(['resonance', 'cascade', 'phase_align', 'weighted_sum'])
        f = getattr(FormulaGrammar, op)(selected, name=f'injected_{i}')
        new_formulas.append(f)

    print(f"    生成 {len(new_formulas)} 个新公式")

    # 2. 快速评估，选Top-5
    print(f"\n[2] 快速评估选Top-5...")
    from formula_lang.evaluator import FormulaEvaluator
    evaluator = FormulaEvaluator()

    top_formulas = []
    for f in new_formulas[:30]:
        perf = evaluator.evaluate(f, draws, n_windows=5, window_size=500, step=50)
        if perf["avg_hits"] > 0.15:
            top_formulas.append((f, perf))

    top_formulas.sort(key=lambda x: -x[1]["avg_hits"])
    top5 = top_formulas[:5]

    print(f"    Top-5 公式:")
    for i, (f, perf) in enumerate(top5):
        print(f"      #{i+1} {f.name}: avg={perf['avg_hits']:.3f} stable={perf['stable']:.3f}")

    # 3. 生成预测
    print(f"\n[3] 生成预测 (第{target_period}期)...")
    predictions = []

    # 传统策略预测
    from enhanced_predictor import WeightedEnsemble
    ensemble = WeightedEnsemble(df)
    trad_preds = ensemble.generate(5)
    for p in trad_preds:
        predictions.append({
            "engine": "Enhanced V2.0",
            "strategy": p["strategy"],
            "reds": p["reds"],
            "blue": p["blue"],
            "causal_valid": p.get("causal_valid", True),
        })

    # 新公式预测
    for formula, perf in top5:
        strat = NewFormulaStrategy(formula, draws, name=formula.name)
        reds = strat.generate()
        blue = random.choice([1, 5, 8, 12, 16])  # 简化：新公式暂不预测蓝球
        predictions.append({
            "engine": "NewFormula",
            "strategy": formula.name,
            "reds": reds,
            "blue": blue,
            "causal_valid": True,
            "backtest_avg": perf["avg_hits"],
        })

    # 4. 融合投票 — 加入因果约束和范围限制
    print(f"\n[4] 融合投票...")
    from collections import Counter
    red_counter = Counter()
    blue_counter = Counter()
    for p in predictions:
        for r in p["reds"]:
            red_counter[r] += 1
        blue_counter[p["blue"]] += 1

    # 先过滤掉不符合因果规则的候选号码集合
    # 规则：和值90-130, 跨度20-32, 奇偶比2:4~4:2
    all_candidates = {n for n, _ in red_counter.items()}

    # 取投票排名前12的号码作为候选池（不是直接取前6）
    top_candidates = [n for n, _ in red_counter.most_common(12)]

    # 暴力搜索：从top_candidates中选6个，使和值在90-130范围内
    from itertools import combinations
    best_combo = None
    best_score = -1

    for combo in combinations(top_candidates, 6):
        s = sum(combo)
        sp = max(combo) - min(combo)
        odds = sum(1 for n in combo if n % 2 == 1)

        # 因果约束
        if not (90 <= s <= 130):
            continue
        if not (20 <= sp <= 32):
            continue
        if not (2 <= odds <= 4):
            continue

        # 评分：投票总和越高越好
        score = sum(red_counter[n] for n in combo)
        if score > best_score:
            best_score = score
            best_combo = combo

    # 如果因果约束太严找不到组合，放宽到top 15
    if best_combo is None:
        wider_candidates = [n for n, _ in red_counter.most_common(15)]
        for combo in combinations(wider_candidates, 6):
            s = sum(combo)
            sp = max(combo) - min(combo)
            odds = sum(1 for n in combo if n % 2 == 1)
            if not (85 <= s <= 135):
                continue
            if not (18 <= sp <= 34):
                continue
            if not (2 <= odds <= 4):
                continue
            score = sum(red_counter[n] for n in combo)
            if score > best_score:
                best_score = score
                best_combo = combo

    # 极端情况：连放宽都找不到，就用投票最高的6个
    if best_combo is None:
        print("    [警告] 因果约束过严，回退到投票最高")
        top_reds = [n for n, _ in red_counter.most_common(6)]
    else:
        top_reds = list(best_combo)

    top_blue = blue_counter.most_common(1)[0][0] if blue_counter else 8

    print(f"\n{'='*70}")
    print(f"  第 {target_period} 期 融合预测（因果约束版）")
    print(f"{'='*70}")
    print(f"\n  [Red] 红球: {sorted(top_reds[:6])}")
    print(f"  [Blue] 蓝球: {top_blue}")
    print(f"\n  [投票详情]")
    for n, count in red_counter.most_common(12):
        print(f"    红球{n:02d}: 被 {count}/{len(predictions)} 个策略选中")

    # 验证因果规则
    final_reds = sorted(top_reds[:6])
    print(f"\n  [因果验证] 和值={sum(final_reds)}, 跨度={max(final_reds)-min(final_reds)}, 奇数={sum(1 for n in final_reds if n%2==1)}")

    # 5. 保存
    output = {
        "period": str(target_period),
        "timestamp": datetime.now().isoformat(),
        "data_periods": len(df),
        "latest_period": latest_period,
        "total_predictions": len(predictions),
        "fused": {
            "reds": sorted(top_reds[:6]),
            "blue": top_blue,
        },
        "individual_predictions": predictions,
        "new_formula_backtest": {
            f.name: {"avg_hits": p["avg_hits"], "stable": p["stable"]}
            for f, p in top5
        },
    }

    with open(_PROJECT_ROOT / "latest_prediction_new_formula.json", "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2)
    print(f"\n  预测已保存: latest_prediction_new_formula.json")

    return output


if __name__ == "__main__":
    inject_and_predict()
