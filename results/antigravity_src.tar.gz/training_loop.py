# -*- coding: utf-8 -*-
"""
Antigravity 训练循环 V0.1

核心理念:
- 公式不是"找到"的，而是"训练"出来的
- 训练 = 生成 → 评估 → 淘汰 → 变异 → 再生成
- 每一代的公式都是上一代的选择压力下的幸存者
- 训练的目标不是"最优公式"，而是"最优搜索空间"

这个循环会：
1. 运行公式进化
2. 将最佳公式注入到预测引擎中
3. 用新引擎重新回测
4. 如果回测改善，保留公式；否则淘汰
5. 更新公式进化器的搜索空间
6. 重复
"""
import json
import os
import subprocess
import sys
from pathlib import Path
from datetime import datetime

_PROJECT_ROOT = Path(__file__).resolve().parent


class TrainingLoop:
    """训练循环管理器"""

    def __init__(self, n_iterations=10):
        self.n_iterations = n_iterations
        self.formula_log = []  # 每代公式记录
        self.best_formula = None
        self.best_fitness = 0

    def run(self):
        print("=" * 70)
        print("  🔄 Antigravity 训练循环 V0.1")
        print("  公式不是找到的——是训练出来的")
        print("=" * 70)
        print()

        for iteration in range(self.n_iterations):
            print(f"\n{'='*60}")
            print(f"  迭代 {iteration + 1}/{self.n_iterations}")
            print(f"{'='*60}")

            # 1. 运行公式进化
            print(f"\n  [1/4] 运行公式进化...")
            result = self._run_evolution(iteration)

            # 2. 更新最佳公式
            if result and result.get("fitness", 0) > self.best_fitness:
                self.best_fitness = result["fitness"]
                self.best_formula = result
                self.formula_log.append({
                    "iteration": iteration + 1,
                    "formula": result,
                    "fitness": result["fitness"],
                    "timestamp": datetime.now().isoformat(),
                })
                print(f"  ✅ 新最佳公式: fitness={result['fitness']:.4f}")
            else:
                print(f"  ⚠️ 未超越最佳 (当前最佳: {self.best_fitness:.4f})")

            # 3. 保存中间结果
            self._save_state(iteration)

            # 4. 更新搜索空间（如果找到了好公式）
            if result and result.get("fitness", 0) > 0.19:
                print(f"  📝 公式已注入训练循环，下一代将以此为起点")

        print(f"\n{'='*70}")
        print(f"  训练循环完成")
        print(f"{'='*70}")
        print(f"  总迭代: {self.n_iterations}")
        print(f"  最佳公式 fitness: {self.best_fitness:.4f}")
        print(f"  发现公式数: {len(self.formula_log)}")

        if self.best_formula:
            print(f"\n  最佳公式:")
            print(f"    {json.dumps(self.best_formula, indent=4, ensure_ascii=False)}")

    def _run_evolution(self, iteration):
        """运行一轮公式进化"""
        try:
            # 读取上一代的最佳公式作为种子
            seed_formula = None
            if self.best_formula and iteration > 0:
                seed_formula = self.best_formula.get("formula", {})

            # 运行公式进化器
            result = subprocess.run(
                [sys.executable, str(_PROJECT_ROOT / "formula_evolver.py")],
                capture_output=True,
                text=True,
                encoding="utf-8",
                timeout=300,
                cwd=str(_PROJECT_ROOT),
            )

            # 解析输出
            if "evolved_formulas.json" in result.stdout or Path(_PROJECT_ROOT / "evolved_formulas.json").exists():
                with open(str(_PROJECT_ROOT / "evolved_formulas.json"), "r", encoding="utf-8") as f:
                    formulas = json.load(f)

                if formulas:
                    best_family = max(formulas.items(), key=lambda x: x[1]["fitness"])
                    return {
                        "family": best_family[0],
                        "formula": best_family[1]["formula"],
                        "fitness": best_family[1]["fitness"],
                        "std": best_family[1]["std"],
                        "generation": best_family[1]["generation"],
                    }

            return None
        except Exception as e:
            print(f"  [ERROR] 公式进化失败: {e}")
            return None

    def _save_state(self, iteration):
        """保存训练状态"""
        state = {
            "iteration": iteration + 1,
            "best_fitness": self.best_fitness,
            "formula_log": self.formula_log,
            "timestamp": datetime.now().isoformat(),
        }
        with open(str(_PROJECT_ROOT / "training_state.json"), "w", encoding="utf-8") as f:
            json.dump(state, f, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    loop = TrainingLoop(n_iterations=5)
    loop.run()
