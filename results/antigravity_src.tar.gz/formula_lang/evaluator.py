# -*- coding: utf-8 -*-
"""
Antigravity 公式语言 — 公式评估器 V1.0

核心理念:
- 每个公式都必须通过 walk-forward 交叉验证
- 不只是看命中率，还要看稳定性（标准差）和统计显著性（p值）
- 评估结果直接用于公式的存活/淘汰决策

用法:
    from formula_lang.evaluator import FormulaEvaluator

    evaluator = FormulaEvaluator()
    result = evaluator.evaluate(formula, draws, n_windows=10, window_size=500, step=50)
    # result = {"avg_hits": 2.3, "std": 0.5, "p_value": 0.03, "rounds": 50, ...}
"""
import math
import json
from pathlib import Path
from typing import Optional, Dict, List, Any
from datetime import datetime
from collections import Counter

_PROJECT_ROOT = Path(__file__).resolve().parent


class FormulaEvaluator:
    """公式评估器 — walk-forward 交叉验证"""

    def __init__(self, random_baseline: float = 1.09):
        """
        Args:
            random_baseline: 理论随机基线的期望命中数 (C(33,6)中随机选6个，期望命中6/33≈1.09)
        """
        self.random_baseline = random_baseline

    def evaluate(self, formula: Any, draws: Any,
                 n_windows: int = 10, window_size: int = 500,
                 step: int = 50) -> Dict:
        """
        评估一个公式。

        Args:
            formula: 公式对象（有 rank_top_6(draws) 方法）
            draws: 历史开奖数据
            n_windows: 验证窗口数
            window_size: 训练窗口大小
            step: 窗口步进

        Returns:
            {
                "avg_hits": 平均命中数,
                "std": 标准差,
                "max_hits": 最大命中数,
                "min_hits": 最小命中数,
                "p_value": t检验p值,
                "rounds": 验证轮数,
                "beats_random": 是否优于随机基线,
                "stable": 稳定性评分 (avg - std),
                "per_round": [每轮的命中数列表],
            }
        """
        per_round_hits = []

        for w in range(n_windows):
            train_end = window_size + w * step
            test_start = train_end + 10
            test_end = test_start + 10

            if test_end > len(draws):
                break

            # 用训练集评估公式（公式内部可能用不到训练数据，但接口保持一致）
            try:
                pred_top6 = formula.rank_top_6(draws[:train_end])
                actual_top6 = draws[test_start:test_end]

                hits = 0
                for draw in actual_top6:
                    actual_reds = draw.reds if hasattr(draw, 'reds') else sorted(list(draw.red))
                    hits += len(set(pred_top6) & set(actual_reds))

                per_round_hits.append(hits / max(len(actual_top6) * 6, 1))
            except Exception:
                per_round_hits.append(0)

        if not per_round_hits:
            return {
                "avg_hits": 0, "std": 1, "max_hits": 0, "min_hits": 0,
                "p_value": 1.0, "rounds": 0, "beats_random": False,
                "stable": -1, "per_round": [],
            }

        avg = sum(per_round_hits) / len(per_round_hits)
        std = math.sqrt(sum((h - avg) ** 2 for h in per_round_hits) / max(len(per_round_hits) - 1, 1))
        max_h = max(per_round_hits)
        min_h = min(per_round_hits)

        # t检验: H0 = 公式效果 = 随机基线
        se = std / math.sqrt(len(per_round_hits)) if std > 0 else 1
        t_stat = (avg - self.random_baseline) / se if se > 0 else 0
        # 简化: 用正态近似计算p值
        p_value = self._t_to_pvalue(t_stat, len(per_round_hits))

        return {
            "avg_hits": round(avg, 4),
            "std": round(std, 4),
            "max_hits": round(max_h, 4),
            "min_hits": round(min_h, 4),
            "p_value": round(p_value, 4),
            "rounds": len(per_round_hits),
            "beats_random": avg > self.random_baseline,
            "stable": round(avg - std, 4),
            "per_round": [round(h, 4) for h in per_round_hits],
        }

    def evaluate_batch(self, formulas: List[Any], draws: Any,
                       **kwargs) -> Dict[str, Dict]:
        """批量评估多个公式"""
        results = {}
        for f in formulas:
            name = getattr(f, 'name', str(f))
            result = self.evaluate(f, draws, **kwargs)
            results[name] = result
        return results

    def _t_to_pvalue(self, t: float, df: int) -> float:
        """
        简化t检验p值计算（正态近似）。
        对于大样本，t分布近似标准正态分布。
        """
        # 用误差函数近似
        x = abs(t) / math.sqrt(2)
        try:
            erf_x = self._erf(x)
            p_one_tail = 0.5 * (1 - erf_x)
            return min(1.0, 2 * p_one_tail)  # 双尾
        except:
            return 1.0

    @staticmethod
    def _erf(x: float) -> float:
        """误差函数近似"""
        # Abramowitz and Stegun approximation
        sign = 1 if x >= 0 else -1
        x = abs(x)
        a1, a2, a3, a4, a5 = 0.254829592, -0.284496736, 1.421413741, -1.453152027, 1.061405429
        p = 0.3275911
        t = 1.0 / (1.0 + p * x)
        y = 1.0 - (((((a5 * t + a4) * t) + a3) * t + a2) * t + a1) * t * math.exp(-x * x)
        return sign * y


def evaluate_formula_against_draws(formula, draws, n_rounds=30, seed=42) -> Dict:
    """
    便捷函数: 用一个公式在历史数据上回测。

    Args:
        formula: 公式对象
        draws: 历史数据
        n_rounds: 回测轮数
        seed: 随机种子

    Returns:
        回测结果字典
    """
    evaluator = FormulaEvaluator()
    return evaluator.evaluate(formula, draws, n_windows=n_rounds, window_size=300, step=30)
