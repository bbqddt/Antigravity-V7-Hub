# -*- coding: utf-8 -*-
"""
Antigravity 公式语言 — 原语变异器 V1.0

核心理念:
- 变异不只是调参数，更要换内部操作（逻辑级变异）
- 逻辑级变异: 把"平均遗漏"换成"中位数遗漏"
- 参数级变异: 把 decay=0.95 换成 decay=0.97
- 变异后的原语自动记录父原语UUID

用法:
    from formula_lang.mutator import PrimitiveMutator

    mutator = PrimitiveMutator()
    child = mutator.mutate(primitive, draws)
"""
import random
import copy
from typing import Optional, List, Any
from formula_lang.primitive import Primitive


class PrimitiveMutator:
    """原语变异器 — 逻辑级 + 参数级变异"""

    def __init__(self, logical_rate: float = 0.3, param_rate: float = 0.5):
        """
        Args:
            logical_rate: 逻辑级变异概率（换内部操作）
            param_rate: 参数级变异概率（调参数值）
        """
        self.logical_rate = logical_rate
        self.param_rate = param_rate

    def mutate(self, primitive: Primitive, draws: Any,
               rng: Optional[random.Random] = None) -> Primitive:
        """
        变异一个原语。

        Args:
            primitive: 要变异的原语
            draws: 历史数据（用于指导变异方向）
            rng: 随机数生成器

        Returns:
            变异后的新原语
        """
        rng = rng or random.Random()
        mutated = primitive.mutate(draws, rng)

        # 参数级变异
        if rng.random() < self.param_rate:
            mutated = self._param_mutate(mutated, rng)

        # 逻辑级变异
        if rng.random() < self.logical_rate:
            mutated = self._logical_mutate(mutated, rng, draws)

        return mutated

    def _param_mutate(self, primitive: Primitive, rng: random.Random) -> Primitive:
        """参数级变异 — 微调参数值"""
        for key in primitive.parameters:
            if isinstance(primitive.parameters[key], (int, float)):
                if rng.random() < 0.5:
                    # 高斯扰动
                    primitive.parameters[key] *= (1 + rng.gauss(0, 0.15))
                else:
                    # 边界内随机重置
                    val = primitive.parameters[key]
                    if 0 < val < 1:
                        primitive.parameters[key] = rng.uniform(0, 1)
                    elif val < 10:
                        primitive.parameters[key] = rng.uniform(val * 0.5, val * 1.5)
                    else:
                        primitive.parameters[key] = max(10, int(rng.gauss(val, val * 0.2)))

        return primitive

    def _logical_mutate(self, primitive: Primitive, rng: random.Random, draws: Any) -> Primitive:
        """
        逻辑级变异 — 换内部操作。

        例如: PeriodicEcho 的 decay 从 0.95 换成 0.85
              RecencyGradient 的 recent_window 从 50 换成 30
        """
        # 对时序原语：改变时间窗口
        if primitive.category == "temporal":
            for key in ["window", "recent_window", "far_window", "lookback", "season_size"]:
                if key in primitive.parameters and primitive.parameters[key] > 5:
                    factor = rng.choice([0.5, 0.7, 1.3, 1.5, 2.0])
                    primitive.parameters[key] = int(primitive.parameters[key] * factor)
                    break

        # 对关系原语：改变阈值
        elif primitive.category == "relational":
            for key in ["threshold"]:
                if key in primitive.parameters:
                    primitive.parameters[key] = max(0.01, primitive.parameters[key] * rng.uniform(0.5, 2.0))

        # 对频谱原语：改变最小峰值数
        elif primitive.category == "spectral":
            for key in ["min_peaks"]:
                if key in primitive.parameters:
                    primitive.parameters[key] = max(1, primitive.parameters[key] + rng.choice([-1, 0, 1]))

        # 对混沌原语：改变嵌入维度
        elif primitive.category == "chaotic":
            for key in ["dim", "tau"]:
                if key in primitive.parameters:
                    primitive.parameters[key] = max(2, min(5, primitive.parameters[key] + rng.choice([-1, 0, 1])))

        return primitive

    def breed(self, p1: Primitive, p2: Primitive, draws: Any,
              rng: Optional[random.Random] = None) -> Primitive:
        """
        杂交两个原语 — 取p1的类别和p2的参数，或反之。

        注意: 这只适用于同类别的原语。
        """
        if p1.category != p2.category:
            # 不同类别，随机选一个
            return rng.choice([p1, p2])

        rng = rng or random.Random()

        # 50%概率用p1的结构+p2的参数
        if rng.random() < 0.5:
            child = copy_primitive(p1)
            child.parameters = dict(p2.parameters)
        else:
            child = copy_primitive(p2)
            child.parameters = dict(p1.parameters)

        child.parents = [p1.uuid, p2.uuid]
        child.origin = "breed"
        child.birth_time = __import__('datetime').datetime.now().isoformat()

        return child


def copy_primitive(p: Primitive) -> Primitive:
    """浅拷贝原语（不深拷贝，避免lambda问题）"""
    import copy
    return copy.deepcopy(p)
