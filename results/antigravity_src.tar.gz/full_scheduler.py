# -*- coding: utf-8 -*-
"""
Antigravity 全自动调度系统 V1.0
=============================
每日自动运行：
1. 数据采集（data_updater_v2.py）
2. 非随机性检测（nonrandomness_detector.py）
3. 预测引擎（orchestrate.py）
4. 滚动回测（walkforward_backtest_v2.py）
5. 自主演进（autonomous_evolution_v2.py）

用法:
    python full_scheduler.py          # 运行一轮
    python full_scheduler.py --loop   # 持续运行
    python full_scheduler.py --daemon # 守护模式（每小时一轮）
"""
import sys
import os
import time
import logging
from pathlib import Path
from datetime import datetime

# Fix Windows GBK
sys.stdout.reconfigure(encoding="utf-8") if hasattr(sys.stdout, 'reconfigure') else None

_PROJECT_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(_PROJECT_ROOT))

# 日志配置
LOG_DIR = _PROJECT_ROOT / "logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)
LOG_FILE = LOG_DIR / "full_scheduler.log"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE, encoding="utf-8"),
        logging.StreamHandler(sys.stdout),
    ],
)
logger = logging.getLogger("FullScheduler")


class FullScheduler:
    """全自动调度器"""

    def __init__(self):
        self.start_time = None
        self.steps = []

    def run_single_cycle(self):
        """运行单轮完整调度"""
        self.start_time = time.time()
        logger.info("=" * 60)
        logger.info("  Antigravity 全自动调度系统 V1.0")
        logger.info("=" * 60)

        # Step 1: 数据采集
        self._step_data_collection()

        # Step 2: 非随机性检测
        self._step_nonrandomness_detection()

        # Step 3: 预测引擎
        self._step_prediction()

        # Step 4: 滚动回测
        self._step_backtest()

        # Step 5: 自主演进（可选，耗时较长）
        self._step_autonomous_evolution()

        elapsed = time.time() - self.start_time
        logger.info(f"\n=== 单轮完成，耗时 {elapsed:.1f}s ===")
        return True

    def _step_data_collection(self):
        """Step 1: 数据采集"""
        logger.info("\n[1/5] 数据采集...")
        try:
            from data_updater_v2 import main as updater_main
            updater_main()
            logger.info("[OK] 数据采集完成")
            self.steps.append(("data_collection", "ok"))
        except Exception as e:
            logger.warning(f"[WARN] 数据采集失败: {e}")
            self.steps.append(("data_collection", f"error: {e}"))

    def _step_nonrandomness_detection(self):
        """Step 2: 非随机性检测"""
        logger.info("\n[2/5] 非随机性检测...")
        try:
            from nonrandomness_detector import run_detection
            run_detection()
            logger.info("[OK] 非随机性检测完成")
            self.steps.append(("nonrandomness", "ok"))
        except Exception as e:
            logger.warning(f"[WARN] 非随机性检测失败: {e}")
            self.steps.append(("nonrandomness", f"error: {e}"))

    def _step_prediction(self):
        """Step 3: 预测引擎"""
        logger.info("\n[3/5] 预测引擎...")
        try:
            from orchestrate import run_full_pipeline
            result = run_full_pipeline()
            logger.info(f"[OK] 预测完成: 目标期号={result.get('target_period', '?')}")
            self.steps.append(("prediction", "ok"))
        except Exception as e:
            logger.warning(f"[WARN] 预测引擎失败: {e}")
            self.steps.append(("prediction", f"error: {e}"))

    def _step_backtest(self):
        """Step 4: 滚动回测"""
        logger.info("\n[4/5] 滚动回测...")
        try:
            from walkforward_backtest_v2 import run as backtest_run
            backtest_run()
            logger.info("[OK] 滚动回测完成")
            self.steps.append(("backtest", "ok"))
        except Exception as e:
            logger.warning(f"[WARN] 滚动回测失败: {e}")
            self.steps.append(("backtest", f"error: {e}"))

    def _step_autonomous_evolution(self):
        """Step 5: 自主演进（轻量版）"""
        logger.info("\n[5/5] 自主演进（轻量版）...")
        try:
            from autonomous_evolution_v2 import AutonomousEvolutionV2
            # 只运行1个周期，轻量版
            evo = AutonomousEvolutionV2(max_cycles=1, formula_population=20, formula_generations=2)
            evo.run()
            logger.info("[OK] 自主演进完成")
            self.steps.append(("evolution", "ok"))
        except Exception as e:
            logger.warning(f"[WARN] 自主演进失败: {e}")
            self.steps.append(("evolution", f"error: {e}"))

    def run_loop(self, interval_seconds=3600):
        """持续运行模式"""
        logger.info(f"进入持续运行模式，间隔 {interval_seconds}s")
        cycle = 0
        while True:
            cycle += 1
            logger.info(f"\n>>> 第 {cycle} 轮 <<<")
            self.run_single_cycle()
            logger.info(f"等待 {interval_seconds}s 后下一轮...")
            time.sleep(interval_seconds)

    def run_daemon(self, interval_hours=1.0):
        """守护模式"""
        logger.info(f"进入守护模式，每 {interval_hours}h 运行一轮")
        cycle = 0
        while True:
            cycle += 1
            self.run_single_cycle()
            wait_secs = int(interval_hours * 3600)
            logger.info(f"等待 {wait_secs}s 后下一轮...")
            time.sleep(wait_secs)


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Antigravity 全自动调度系统")
    parser.add_argument("--loop", action="store_true", help="持续运行模式（每小时一轮）")
    parser.add_argument("--daemon", action="store_true", help="守护模式（后台运行）")
    parser.add_argument("--interval", type=int, default=3600, help="循环间隔秒数（默认3600）")
    parser.add_argument("--daemon-hours", type=float, default=1.0, help="守护模式间隔小时数")
    args = parser.parse_args()

    scheduler = FullScheduler()

    if args.loop:
        scheduler.run_loop(interval_seconds=args.interval)
    elif args.daemon:
        scheduler.run_daemon(interval_hours=args.daemon_hours)
    else:
        scheduler.run_single_cycle()
