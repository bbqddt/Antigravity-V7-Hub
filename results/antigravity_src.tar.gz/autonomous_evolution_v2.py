# -*- coding: utf-8 -*-
"""
Antigravity 自主演进循环 V2.0 — 智能进化引擎协同公式开发

核心理念:
- 不预设方向，让数据自己说话
- 公式语言的原语是"积木"，自主进化引擎是"建筑师"
- 策略框架的假设是"种子"，回测验证是"筛子"
- LLM创新是"灵感"，系统实现和验证是"裁判"
- 四大模块协同工作，形成完整的"开发→进化→验证→淘汰"闭环

演进循环:
1. 非随机性检测 → 提取数据信号
2. 策略框架 → 从信号生成假设
3. 公式语言 → 用新原语开发公式
4. 自主进化 → 公式变异+杂交，持续进化
5. 回测验证 → 淘汰差的，保留好的
6. LLM创新 → 分析失败，提出新方向
7. 融合预测 → 所有存活策略投票
8. 保存状态 → 下一周期继续
"""
import json
import sys
from pathlib import Path
from datetime import datetime
from collections import Counter

_PROJECT_ROOT = Path(__file__).resolve().parent

# 确保路径
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

from data_layer import load_history


class AutonomousEvolutionV2:
    """智能进化引擎 V2 — 四大模块协同"""

    def __init__(self, max_cycles=100, formula_population=200, formula_generations=10):
        self.max_cycles = max_cycles
        self.formula_population = formula_population
        self.formula_generations = formula_generations
        self.signal_log = []
        self.cycle = 0
        self.draws = None
        self.evolution_state = {}

    def run(self):
        print("=" * 70)
        print("  Antigravity 自主演进循环 V2.0")
        print("  智能进化引擎 × 公式语言 × 策略框架 × LLM创新")
        print("=" * 70)
        print()

        # 加载数据
        print("加载历史数据...")
        self.draws = load_history()
        print(f"  数据: {len(self.draws)} 期")
        print()

        for cycle in range(1, self.max_cycles + 1):
            self.cycle = cycle
            print(f"\n{'='*60}")
            print(f"  周期 {cycle}/{self.max_cycles}")
            print(f"{'='*60}")

            # 1. 非随机性检测（轻量版）
            signals = self._step_nonrandomness_detection()

            # 2. 策略生成
            strategy_signals = self._step_strategy_generation()
            signals.extend(strategy_signals)

            # 3. 公式开发（轻量版，每代100公式）
            formula_signals = self._step_formula_development()
            signals.extend(formula_signals)

            # 4. 自主进化
            evolution_signals = self._step_autonomous_evolution()
            signals.extend(evolution_signals)

            # 5. 回测验证
            backtest_signals = self._step_backtest_verification()
            signals.extend(backtest_signals)

            # 6. LLM创新分析
            llm_signals = self._step_llm_innovation()
            signals.extend(llm_signals)

            # 7. 融合预测
            prediction = self._step_fusion_prediction()

            # 8. 记录信号
            self._record_signals(signals)

            # 9. 持久化
            self._save_state(prediction)

            # 每10周期打印存活信号
            if cycle % 10 == 0:
                persistent = self._find_persistent_signals()
                print(f"\n  [存活信号 {len(persistent)}个]:")
                for s in persistent[:5]:
                    print(f"    - {s}")

        print(f"\n{'='*70}")
        print(f"  自主演进循环完成: {self.max_cycles} 周期")
        print(f"  发现信号总数: {len(self.signal_log)}")
        print(f"{'='*70}")

    def _step_nonrandomness_detection(self):
        """步骤1: 非随机性检测（轻量版）"""
        signals = []
        try:
            from nonrandomness_detector import run_detection
            result = run_detection()
            signals.append({
                "module": "nonrandomness_detector",
                "cycle": self.cycle,
                "keyword": "detection_complete",
                "signal": "非随机性检测完成",
            })
        except Exception as e:
            signals.append({
                "module": "nonrandomness_detector",
                "cycle": self.cycle,
                "keyword": "error",
                "signal": str(e)[:200],
            })
        return signals

    def _step_strategy_generation(self):
        """步骤2: 策略生成"""
        signals = []
        try:
            from strategy_proposer import HypothesisGenerator, HypothesisValidator, StrategyRegistry

            gen = HypothesisGenerator()
            hypotheses = gen.generate_from_signals()
            print(f"  [策略生成] {len(hypotheses)} 个假设")

            validator = HypothesisValidator()
            results = validator.validate_all(hypotheses, self.draws,
                                             n_windows=5, window_size=300, step=30)

            survived = sum(1 for r in results.values() if r.get("status") == "survived")
            eliminated = sum(1 for r in results.values() if r.get("status") == "eliminated")
            print(f"  [验证结果] {survived} 存活 / {eliminated} 淘汰")

            # 注册
            registry = StrategyRegistry()
            for h in hypotheses:
                registry.add(h)
            registry.save()

            signals.append({
                "module": "strategy_proposer",
                "cycle": self.cycle,
                "keyword": "hypothesis",
                "signal": f"生成{len(hypotheses)}假设, 存活{survived}",
            })
        except Exception as e:
            signals.append({
                "module": "strategy_proposer",
                "cycle": self.cycle,
                "keyword": "error",
                "signal": str(e)[:200],
            })
        return signals

    def _step_formula_development(self):
        """步骤3: 公式开发（轻量版）"""
        signals = []
        try:
            from formula_lang import get_default_primitives, FormulaGrammar
            from formula_lang.evaluator import FormulaEvaluator
            import random

            primitives = get_default_primitives()
            n_formulas = min(100, len(primitives) ** 3)  # 限制公式数

            formulas = []
            for i in range(n_formulas):
                n_prims = random.randint(2, min(4, len(primitives)))
                selected = random.sample(primitives, n_prims)
                op = random.choice(['resonance', 'cascade', 'phase_align', 'weighted_sum'])
                f = getattr(FormulaGrammar, op)(selected, name=f'cycle{self.cycle}_f{i}')
                formulas.append(f)

            evaluator = FormulaEvaluator()
            results = evaluator.evaluate_batch(formulas, self.draws,
                                               n_windows=5, window_size=300, step=30)

            scored = [(f, results.get(f.name, {})) for f in formulas]
            scored.sort(key=lambda x: -x[1].get('avg_hits', 0))

            if scored:
                best = scored[0]
                print(f"  [公式开发] {n_formulas}公式, Top-1: avg={best[1].get('avg_hits', 0):.4f}")

                # 保存最佳公式
                if best[1].get('avg_hits', 0) > 0.2:
                    signals.append({
                        "module": "formula_development",
                        "cycle": self.cycle,
                        "keyword": "formula",
                        "signal": f"最佳公式: {best[0].name[:40]}, avg={best[1]['avg_hits']:.4f}",
                    })
            else:
                print(f"  [公式开发] {n_formulas}公式, 无有效结果")
        except Exception as e:
            signals.append({
                "module": "formula_development",
                "cycle": self.cycle,
                "keyword": "error",
                "signal": str(e)[:200],
            })
        return signals

    def _step_autonomous_evolution(self):
        """步骤4: 自主进化（轻量版）"""
        signals = []
        try:
            from formula_lang import get_default_primitives, FormulaGrammar
            from formula_lang.evaluator import FormulaEvaluator
            from formula_lang.mutator import PrimitiveMutator
            import random

            primitives = get_default_primitives()
            population_size = min(self.formula_population, 50)  # 轻量版限制
            n_generations = min(self.formula_generations, 5)

            # 初始化
            population = []
            for i in range(population_size):
                n_prims = random.randint(2, min(4, len(primitives)))
                selected = random.sample(primitives, n_prims)
                op = random.choice(['resonance', 'cascade', 'phase_align', 'weighted_sum'])
                f = getattr(FormulaGrammar, op)(selected, name=f'evo_gen0_{i}')
                population.append((f, None))

            evaluator = FormulaEvaluator()
            mutator = PrimitiveMutator()

            for gen in range(n_generations):
                # 评估
                formulas = [f for f, _ in population]
                results = evaluator.evaluate_batch(formulas, self.draws,
                                                   n_windows=5, window_size=300, step=30)
                for i, (f, _) in enumerate(population):
                    perf = results.get(f.name, {})
                    population[i] = (f, perf)

                # 排序
                evaluated = [(f, p) for f, p in population if p is not None]
                evaluated.sort(key=lambda x: -x[1].get('avg_hits', 0))

                if evaluated and gen == n_generations - 1:
                    best = evaluated[0]
                    print(f"  [自主进化] {n_generations}代, Top: {best[0].name[:40]} avg={best[1]['avg_hits']:.4f}")

                    signals.append({
                        "module": "autonomous_evolution",
                        "cycle": self.cycle,
                        "keyword": "evolution",
                        "signal": f"代{gen+1}: {best[1]['avg_hits']:.4f}",
                    })

                # 选择精英
                elites = evaluated[:max(1, len(evaluated) // 5)]
                if not elites:
                    break

                # 下一代
                new_pop = list(elites)
                while len(new_pop) < population_size:
                    parent = random.choice(elites)
                    child = mutator.mutate_formula(parent[0])
                    new_pop.append((child, None))
                population = new_pop
        except Exception as e:
            signals.append({
                "module": "autonomous_evolution",
                "cycle": self.cycle,
                "keyword": "error",
                "signal": str(e)[:200],
            })
        return signals

    def _step_backtest_verification(self):
        """步骤5: 回测验证 — 每10周期才跑一次，平时跳过"""
        signals = []
        if self.cycle % 10 != 0:
            return signals  # 快速模式，跳过回测
        try:
            from new_formula_backtest import run_comparison_backtest
            result = run_comparison_backtest()
            signals.append({
                "module": "backtest_verification",
                "cycle": self.cycle,
                "keyword": "backtest",
                "signal": f"传统={result.get('traditional_avg', 0):.3f}, 新公式={result.get('new_formula_avg', 0):.3f}",
            })
        except Exception as e:
            signals.append({
                "module": "backtest_verification",
                "cycle": self.cycle,
                "keyword": "error",
                "signal": str(e)[:200],
            })
        return signals

    def _step_llm_innovation(self):
        """步骤6: LLM创新分析 — 全渠道AI协同"""
        signals = []
        try:
            from llm_innovation.llm_engine import LLMEngine
            import json as json_mod

            llm = LLMEngine()
            status = llm.get_status()
            print(f"  [LLM引擎] {status['providers_configured']}供应商就绪")

            if llm.available:
                # 1. 读取失败的假设
                eliminated = []
                try:
                    with open(_PROJECT_ROOT / "strategy_registry.json", "r", encoding="utf-8") as f:
                        registry = json_mod.load(f)
                        for hid, h in registry.get("hypotheses", {}).items():
                            if h.get("status") == "eliminated":
                                eliminated.append({
                                    "id": h.get("id"),
                                    "statement": h.get("statement", "")[:150],
                                    "category": h.get("template_category", ""),
                                })
                except:
                    pass

                if eliminated:
                    elim_summary = json_mod.dumps({
                        "total": len(eliminated),
                        "categories": dict(Counter(h["category"] for h in eliminated)),
                        "examples": [e["statement"] for e in eliminated[:3]],
                    }, ensure_ascii=False, indent=2)

                    prompt = f"""以下是{len(eliminated)}个失败的预测假设，请分析失败原因并给出改进方向：

{elim_summary}

失败共性：所有假设的avg_hits都低于1.09（随机基线）。
请给出3条具体的、可操作的建议，每条不超过50字。"""

                    analysis = llm.generate(prompt, max_tokens=1500)
                    if analysis:
                        print(f"  [LLM分析] 使用{llm.active_provider}: {analysis[:150]}...")
                        signals.append({
                            "module": "llm_innovation",
                            "cycle": self.cycle,
                            "keyword": "failure_analysis",
                            "signal": f"分析了{len(eliminated)}个失败假设",
                        })

                # 2. 让LLM提出新原语规格
                prompt_specs = """请提出3个全新的双色球预测原语规格，要求：
- 基于Hurst指数<0.3（强均值回归）和频谱周期信号(28/50/84期)
- 每个原语包含：name, category, description, parameters
- 必须是JSON数组格式
- 不要用传统的频率/遗漏/连号思路"""

                specs = llm.generate(prompt_specs, max_tokens=3000)
                if specs:
                    import re
                    json_match = re.search(r'\[.*\]', specs, re.DOTALL)
                    if json_match:
                        try:
                            parsed = json_mod.loads(json_match.group())
                            print(f"  [LLM新原语] 收到{len(parsed)}个规格")
                            for sp in parsed:
                                print(f"    - {sp.get('name', '?')}: {sp.get('description', '')[:60]}")
                            signals.append({
                                "module": "llm_innovation",
                                "cycle": self.cycle,
                                "keyword": "new_specs",
                                "signal": f"LLM提出{len(parsed)}个新原语规格",
                            })
                        except:
                            signals.append({
                                "module": "llm_innovation",
                                "cycle": self.cycle,
                                "keyword": "llm_specs",
                                "signal": f"LLM生成规格(解析失败)",
                            })
            else:
                signals.append({
                    "module": "llm_innovation",
                    "cycle": self.cycle,
                    "keyword": "llm_offline",
                    "signal": "所有LLM不可用",
                })
        except Exception as e:
            signals.append({
                "module": "llm_innovation",
                "cycle": self.cycle,
                "keyword": "error",
                "signal": str(e)[:200],
            })
        return signals

    def _step_fusion_prediction(self):
        """步骤7: 融合预测"""
        try:
            from inject_new_formulas import inject_and_predict
            prediction = inject_and_predict()
            fused = prediction.get("fused", {})
            print(f"\n  [融合预测] 红球: {fused.get('reds', [])} | 蓝球: {fused.get('blue', '?')}")
            return prediction
        except Exception as e:
            print(f"  [融合预测] 错误: {e}")
            return None

    def _record_signals(self, signals):
        """记录信号"""
        for s in signals:
            key = f"{s['module']}:{s['cycle']}:{s['keyword']}"
            if not any(sig["key"] == key for sig in self.signal_log):
                s["key"] = key
                self.signal_log.append(s)

    def _find_persistent_signals(self):
        """查找存活超过3轮的信号"""
        keywords = Counter()
        for s in self.signal_log:
            keywords[s["keyword"]] += 1
        return [kw for kw, count in keywords.items() if count >= 3]

    def _save_state(self, prediction=None):
        """保存状态"""
        state = {
            "cycle": self.cycle,
            "total_signals": len(self.signal_log),
            "persistent_signals": self._find_persistent_signals(),
            "last_run": datetime.now().isoformat(),
            "prediction": prediction,
        }
        with open(str(_PROJECT_ROOT / "evolution_state_v2.json"), "w", encoding="utf-8") as f:
            json.dump(state, f, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Antigravity 自主演进循环 V2.0")
    parser.add_argument("--cycles", type=int, default=5, help="运行周期数")
    parser.add_argument("--formula-pop", type=int, default=100, help="公式开发种群大小")
    parser.add_argument("--formula-gen", type=int, default=5, help="公式进化代数")
    args = parser.parse_args()

    loop = AutonomousEvolutionV2(
        max_cycles=args.cycles,
        formula_population=args.formula_pop,
        formula_generations=args.formula_gen,
    )
    loop.run()
