# -*- coding: utf-8 -*-
"""
Antigravity 统一编排入口

用法:
    python orchestrate.py              # 运行全部引擎 + 因果验证 + 保存统一输出
    python orchestrate.py --engine luckcast  # 只运行 Luckcast
    python orchestrate.py --engine enhanced    # 只运行 Enhanced
    python orchestrate.py --causal-only        # 只运行因果验证报告
"""

import json
import sys
import time
import logging
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Optional

# Fix Windows GBK
if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8")

_PROJECT_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(_PROJECT_ROOT))

from data_layer import load_history, Draw

logger = logging.getLogger("Orchestrator")
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")


# ─── 引擎调用器 ─────────────────────────────────────────────

def run_luckcast(draws: List[Draw], top_k: int = 5) -> Optional[List[Dict]]:
    """运行 Luckcast V15 预测引擎"""
    try:
        from luckcast_antigravity_v1 import rank_candidates
        results = rank_candidates(draws, n_candidates=1000, top_k=top_k)
        return [
            {
                "engine": "Luckcast V15",
                "reds": list(r[0]),
                "blue": int(r[1]),
                "scores": {k: float(v) for k, v in r[2].items()},
            }
            for r in results
        ]
    except Exception as e:
        logger.error(f"Luckcast V15 失败: {e}")
        return None


def run_enhanced(draws: List[Draw], top_k: int = 5) -> Optional[List[Dict]]:
    """运行 Enhanced Predictor V2.0"""
    try:
        # 临时加载 DataFrame
        import pandas as pd
        csv_file = _PROJECT_ROOT / "data" / "lottery_history.csv"
        df = pd.read_csv(csv_file)

        from enhanced_predictor import WeightedEnsemble, parse_reds
        ensemble = WeightedEnsemble(df)
        preds = ensemble.generate(num_groups=top_k)
        return [
            {
                "engine": "Enhanced V2.0",
                "strategy": p.get("strategy", ""),
                "reds": list(p["reds"]),
                "blue": int(p["blue"]),
                "scores": {
                    "causal_valid": p.get("causal_valid", True),
                    "causal_multiplier": p.get("causal_multiplier", 1.0),
                },
            }
            for p in preds
        ]
    except Exception as e:
        logger.error(f"Enhanced Predictor 失败: {e}")
        return None


def run_evolution_life(draws: List[Draw], top_k: int = 1) -> Optional[List[Dict]]:
    """运行 Evolution Life (RF+Spectral)"""
    try:
        import importlib.util
        spec = importlib.util.spec_from_file_location("evolution_life", _PROJECT_ROOT / "evolution_life.py")
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        result = mod.run_prediction()
        if result and "predictions" in result:
            return result["predictions"]
        return [{"engine": "Evolution Life", "reds": [], "blue": 0, "scores": {}}]
    except Exception as e:
        logger.error(f"Evolution Life 失败: {e}")
        return None


# ─── 因果验证器 ─────────────────────────────────────────────

def causal_verify_all(predictions: List[Dict]) -> List[Dict]:
    """对一组预测做完整的因果验证报告"""
    try:
        from core.causal_reasoning import CausalAnalyzer
        analyzer = CausalAnalyzer()
    except ImportError:
        return predictions

    verified = []
    for p in predictions:
        reds = p.get("reds", [])
        blue = p.get("blue", 0)
        reds_str = ", ".join(str(r) for r in reds)
        result = analyzer.evaluate_causality(reds_str, str(blue))

        p["causal_status"] = result.get("status", "unknown")
        p["causal_multiplier"] = result.get("confidence_multiplier", 1.0)
        p["causal_warnings"] = result.get("warnings", [])
        p["causal_metrics"] = result.get("metrics", {})
        verified.append(p)

    return verified


# ─── 融合引擎 ───────────────────────────────────────────────

def fuse_predictions(all_results: Dict[str, List[Dict]]) -> List[Dict]:
    """
    多引擎结果融合。
    策略: 对所有引擎预测的号码做跨引擎共振计数 + 因果加权。
    """
    from collections import Counter

    # 收集所有预测
    all_preds = []
    for engine_name, preds in all_results.items():
        if preds:
            for p in preds:
                p["_engine"] = engine_name
                all_preds.append(p)

    if not all_preds:
        return []

    # 按红球组合分组（忽略蓝球）
    combo_counter: Counter = Counter()
    combo_map: Dict[tuple, List[Dict]] = {}
    for p in all_preds:
        key = tuple(p["reds"])
        combo_counter[key] += 1
        if key not in combo_map:
            combo_map[key] = []
        combo_map[key].append(p)

    # 跨引擎共振的组合得分更高
    fused = []
    for combo, count in combo_counter.most_common(20):
        if count < 2:
            continue  # 只保留至少2个引擎都推荐的组合
        candidates = combo_map[combo]
        # 取蓝球得票最多的
        blue_counter = Counter()
        best_score = 0
        for c in candidates:
            b = c.get("blue", 0)
            s = c.get("scores", {})
            total = s.get("total_score", s.get("causal_multiplier", 0))
            blue_counter[b] += total
            best_score += total

        best_blue = blue_counter.most_common(1)[0][0] if blue_counter else 0

        fused.append({
            "engine": f"Fusion({count} engines)",
            "reds": list(combo),
            "blue": int(best_blue),
            "cross_engine_support": count,
            "fused_score": round(best_score, 4),
            "contributing_engines": [c.get("_engine", "") for c in candidates],
        })

    return fused


# ─── 主流程 ─────────────────────────────────────────────────

def run_full_pipeline(top_k: int = 5) -> Dict:
    """完整流水线: 数据加载 → 多引擎预测 → 因果验证 → 融合 → 保存"""
    start = time.time()
    logger.info("=" * 60)
    logger.info("  Antigravity 统一编排系统 V1.0")
    logger.info("=" * 60)

    # 1. 加载数据
    draws = load_history()
    latest = draws[-1]
    target = latest.period + 1
    logger.info(f"数据: {len(draws)} 期 | 最新: #{latest.period} | 目标: #{target}")

    # 2. 运行引擎
    all_results: Dict[str, List[Dict]] = {}

    engines = {
        "Luckcast V15": run_luckcast,
        "Enhanced V2.0": run_enhanced,
    }

    for name, runner in engines.items():
        logger.info(f"🚀 启动 {name}...")
        t0 = time.time()
        results = runner(draws, top_k=top_k)
        elapsed = time.time() - t0
        if results:
            all_results[name] = results
            logger.info(f"✅ {name}: {len(results)} 组预测 ({elapsed:.1f}s)")
        else:
            logger.warning(f"❌ {name}: 失败")

    # 3. 因果验证
    logger.info("\n🔬 因果验证...")
    verified_results = {}
    for name, preds in all_results.items():
        verified_results[name] = causal_verify_all(preds)

    # 4. 融合
    logger.info("\n🔗 多引擎融合...")
    fused = fuse_predictions(verified_results)
    if fused:
        logger.info(f"✅ 融合结果: {len(fused)} 组跨引擎共振号码")
    else:
        logger.info("⚠️ 无跨引擎共振组合")

    # 5. 保存统一输出
    output = {
        "target_period": target,
        "timestamp": datetime.now().isoformat(),
        "data_periods": len(draws),
        "latest_period": latest.period,
        "latest_actual": {
            "reds": list(latest.reds),
            "blue": latest.blue,
        },
        "engines": {
            name: {
                "status": "ok" if preds else "fail",
                "count": len(preds) if preds else 0,
                "predictions": preds,
            }
            for name, preds in verified_results.items()
        },
        "fusion": fused,
        "elapsed_seconds": round(time.time() - start, 2),
    }

    # 保存标准格式
    output_path = _PROJECT_ROOT / "latest_prediction.json"
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2)

    # 同时保存兼容旧格式的 latest_decision.json
    if fused:
        best = fused[0]
        legacy = {
            "period": str(target),
            "red": best["reds"],
            "blue": best["blue"],
            "engine": "Fusion",
            "scores": {"fused_score": best.get("fused_score", 0)},
        }
    elif verified_results:
        # 取第一个引擎的第一组
        first_engine = list(verified_results.keys())[0]
        first_pred = verified_results[first_engine][0]
        legacy = {
            "period": str(target),
            "red": first_pred["reds"],
            "blue": first_pred["blue"],
            "engine": first_engine,
            "scores": first_pred.get("scores", {}),
        }
    else:
        legacy = {"period": str(target), "red": [], "blue": 0, "engine": "none"}

    legacy_path = _PROJECT_ROOT / "latest_decision.json"
    with open(legacy_path, "w", encoding="utf-8") as f:
        json.dump(legacy, f, ensure_ascii=False, indent=2)

    # 6. 打印报告
    logger.info(f"\n{'='*60}")
    logger.info(f"  预测结果 - 第 {target} 期")
    logger.info(f"{'='*60}")

    for name, preds in verified_results.items():
        logger.info(f"\n  [{name}]")
        for p in preds[:3]:  # 只显示前3组
            reds = ", ".join(f"{r:02d}" for r in p.get("reds", []))
            blue = f"{p.get('blue', 0):02d}"
            causal = p.get("causal_status", "?")
            mult = p.get("causal_multiplier", 1.0)
            logger.info(f"    🔴[{reds}] 🔵{blue} | 因果:{causal} (x{mult:.2f})")

    if fused:
        logger.info(f"\n  [融合结果]")
        for p in fused[:3]:
            reds = ", ".join(f"{r:02d}" for r in p.get("reds", []))
            blue = f"{p.get('blue', 0):02d}"
            support = p.get("cross_engine_support", 0)
            logger.info(f"    🔴[{reds}] 🔵{blue} | 跨引擎支持:{support} 引擎:{p.get('contributing_engines', [])}")

    logger.info(f"\n✅ 总耗时: {output['elapsed_seconds']}s")
    logger.info(f"📄 输出: {output_path}")

    return output


# ─── CLI ────────────────────────────────────────────────────

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Antigravity 统一编排系统")
    parser.add_argument("--engine", choices=["luckcast", "enhanced", "all"], default="all")
    parser.add_argument("--top-k", type=int, default=5, help="每组预测几组号码")
    parser.add_argument("--causal-only", action="store_true", help="只运行因果验证")
    args = parser.parse_args()

    draws = load_history()

    if args.causal_only:
        logger.info("因果验证器独立运行模式")
        from core.causal_reasoning import CausalAnalyzer
        analyzer = CausalAnalyzer()
        # 测试最近10期
        for d in draws[-10:]:
            reds_str = ", ".join(str(r) for r in d.reds)
            result = analyzer.evaluate_causality(reds_str, str(d.blue))
            logger.info(f"#{d.period}: {d.reds} + {d.blue} → {result['status']} (x{result['confidence_multiplier']:.2f})")
    else:
        run_full_pipeline(top_k=args.top_k)
