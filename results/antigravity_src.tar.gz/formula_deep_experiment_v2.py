# -*- coding: utf-8 -*-
"""
公式深度实验 V2 — 严格前向滚动回测

关键修正:
1. 只用t-1之前的数据预测t（不能看到未来）
2. 每轮独立创建原语实例（避免状态污染）
3. 扩大回测窗口到全部数据
4. 记录每轮的详细命中数
"""
import sys
import json
import numpy as np
from pathlib import Path
from datetime import datetime
from collections import Counter

_PROJECT_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(_PROJECT_ROOT))

from data_layer import load_history, Draw
from formula_lang import get_default_primitives, FormulaGrammar


def strict_walkforward(draws, predictor_fn, warmup=50, backtest_rounds=None):
    """
    严格前向滚动回测

    predictor_fn(draws[:i]) -> list of 6 red balls
    """
    if backtest_rounds is None:
        backtest_rounds = len(draws) - warmup - 1

    hits = []
    for i in range(warmup, warmup + backtest_rounds):
        if i >= len(draws):
            break

        # 训练数据：前i期
        train = draws[:i]

        # 预测
        try:
            pred = predictor_fn(train)
            if not pred or len(pred) < 6:
                continue

            # 实际开奖
            actual = draws[i - 1]
            actual_reds = set(actual.reds if hasattr(actual, 'reds')
                             else sorted(list(actual.red)))

            pred_reds = set(pred[:6])
            hit = len(actual_reds & pred_reds)
            hits.append(hit)
        except Exception as e:
            hits.append(0)

    return hits


def experiment_primitive(name, prim_class, **kwargs):
    """对单个原语做严格回测"""
    draws = load_history()

    def predictor(train_draws):
        prim = prim_class(**kwargs)
        scores = prim.score_all(train_draws)
        top6 = sorted(scores.items(), key=lambda x: -x[1])[:6]
        return [n for n, s in top6]

    hits = strict_walkforward(draws, predictor, warmup=100, backtest_rounds=500)
    return hits


def experiment_formula(name, formula_fn, **kwargs):
    """对公式做严格回测"""
    draws = load_history()
    primitives = get_default_primitives()

    def predictor(train_draws):
        prims = primitives[:5]  # 用前5个原语做测试
        formula = formula_fn(prims, **kwargs)
        top6 = formula.rank_top_6(train_draws)
        return top6[:6]

    hits = strict_walkforward(draws, predictor, warmup=100, backtest_rounds=500)
    return hits


def main():
    print("=" * 70)
    print("  公式深度实验 V2 — 严格前向滚动回测")
    print("=" * 70)

    from formula_lang.primitive import (
        PairOrbit, CooccurrenceAffinity, DistanceCluster,
        MultiScaleFrequency, ModuloClassDistribution, DigitPairFrequency,
        TailRiskSignal, SumRangeTracker, DigitManifold, LyapunovSignal,
    )

    # ─── 实验1: Top原语严格回测 ───
    print("\n[1] Top原语严格回测 (500轮, 100轮预热)...")
    print("-" * 60)

    top_primitives = [
        ("PairOrbit(lookback=100)", PairOrbit, {"lookback": 100}),
        ("PairOrbit(lookback=200)", PairOrbit, {"lookback": 200}),
        ("PairOrbit(lookback=50)", PairOrbit, {"lookback": 50}),
        ("CooccurrenceAffinity(lookback=100)", CooccurrenceAffinity, {"lookback": 100}),
        ("CooccurrenceAffinity(lookback=200)", CooccurrenceAffinity, {"lookback": 200}),
        ("DistanceCluster(lookback=100)", DistanceCluster, {"lookback": 100}),
        ("MultiScaleFrequency", MultiScaleFrequency, {}),
        ("ModuloClassDistribution", ModuloClassDistribution, {}),
        ("DigitPairFrequency", DigitPairFrequency, {}),
        ("TailRiskSignal", TailRiskSignal, {}),
        ("SumRangeTracker", SumRangeTracker, {}),
        ("DigitManifold", DigitManifold, {}),
        ("LyapunovSignal", LyapunovSignal, {}),
    ]

    results = {}
    for label, cls, kwargs in top_primitives:
        hits = experiment_primitive(label, cls, **kwargs)
        if hits:
            avg = np.mean(hits)
            std = np.std(hits)
            median = np.median(hits)
            max_hit = max(hits)
            results[label] = {
                "avg": round(avg, 4),
                "std": round(std, 4),
                "median": round(median, 4),
                "max": max_hit,
                "rounds": len(hits),
                "histogram": {
                    "0": sum(1 for h in hits if h == 0),
                    "1": sum(1 for h in hits if h == 1),
                    "2": sum(1 for h in hits if h == 2),
                    "3": sum(1 for h in hits if h == 3),
                    "4+": sum(1 for h in hits if h >= 4),
                }
            }
            print(f"  {label:45s} avg={avg:.3f} med={median:.1f} max={max_hit} "
                  f"hist={results[label]['histogram']}")

    # ─── 实验2: 公式组合 ───
    print("\n[2] 公式组合回测...")
    print("-" * 60)

    draws = load_history()
    primitives = get_default_primitives()

    # 用PairOrbit + CooccurrenceAffinity做共振公式
    pair_orbit = PairOrbit(lookback=100)
    cooccur = CooccurrenceAffinity(lookback=100)

    def formula_predictor(formula):
        def predictor(train):
            top6 = formula.rank_top_6(train)
            return top6[:6]
        return predictor

    formulas_to_test = [
        ("resonance(PairOrbit, Cooccurrence)",
         FormulaGrammar.resonance([pair_orbit, cooccur], name="res_po_co")),
        ("cascade(PairOrbit, Cooccurrence)",
         FormulaGrammar.cascade([pair_orbit, cooccur], name="cas_po_co")),
        ("weighted_sum(PairOrbit, Cooccurrence)",
         FormulaGrammar.weighted_sum([pair_orbit, cooccur], name="ws_po_co")),
    ]

    for label, formula in formulas_to_test:
        hits = strict_walkforward(draws, formula_predictor(formula), warmup=100, backtest_rounds=500)
        if hits:
            avg = np.mean(hits)
            std = np.std(hits)
            results[f"Formula: {label}"] = {
                "avg": round(avg, 4),
                "std": round(std, 4),
                "median": round(np.median(hits), 4),
                "max": max(hits),
                "rounds": len(hits),
            }
            print(f"  {label:50s} avg={avg:.3f} std={std:.3f} med={np.median(hits):.1f}")

    # ─── 实验3: 多原语组合 ───
    print("\n[3] 多原语加权求和...")
    print("-" * 60)

    # 选出Top-5原语做简单加权投票
    top5_names = ["pair_orbit", "cooccurrence_affinity", "distance_cluster",
                  "digit_pair_freq", "multi_scale_frequency"]
    top5_prims = [p for p in primitives if p.name in top5_names][:5]

    # 不同权重方案
    weight_schemes = [
        ("equal_weight", [1, 1, 1, 1, 1]),
        ("performance_weighted", [4.1, 1.6, 1.6, 1.6, 1.5]),
        ("pair_orbit_heavy", [4.0, 1.0, 1.0, 1.0, 1.0]),
        ("top2_only", [0, 2.0, 0, 0, 0]),
        ("top2_equal", [0, 1.0, 0, 0, 1.0]),
    ]

    for scheme_name, weights in weight_schemes:
        if max(weights) == 0:
            continue

        def multi_prim_predictor(prims, wts):
            def predictor(train):
                all_scores = {}
                for prim, wt in zip(prims, wts):
                    if wt == 0:
                        continue
                    scores = prim.score_all(train)
                    for n, s in scores.items():
                        all_scores[n] = all_scores.get(n, 0) + s * wt
                top6 = sorted(all_scores.items(), key=lambda x: -x[1])[:6]
                return [n for n, s in top6]
            return predictor

        hits = strict_walkforward(
            draws,
            multi_prim_predictor(top5_prims, weights),
            warmup=100, backtest_rounds=500
        )

        if hits:
            avg = np.mean(hits)
            results[f"MultiPrim({scheme_name})"] = {
                "avg": round(avg, 4),
                "std": round(float(np.std(hits)), 4),
                "median": round(float(np.median(hits)), 4),
                "max": max(hits),
                "rounds": len(hits),
            }
            print(f"  {scheme_name:30s} avg={avg:.3f} std={np.std(hits):.3f}")

    # ─── 随机基线 ───
    print("\n[4] 随机基线对比...")
    print("-" * 60)
    print(f"  理论期望: 红球命中1.09/6")
    print(f"  best-of-5随机: 红球命中~1.99/6")
    print(f"  500轮随机平均: ~2.00/6")

    # ─── 汇总 ───
    print("\n" + "=" * 70)
    print("  最终汇总 (按avg_hits排序)")
    print("=" * 70)

    sorted_results = sorted(results.items(), key=lambda x: -x[1]['avg'])
    for name, r in sorted_results:
        hist = r.get('histogram', {})
        hist_str = f"0:{hist.get('0',0)} 1:{hist.get('1',0)} 2:{hist.get('2',0)} 3:{hist.get('3',0)} 4+:{hist.get('4+',0)}" if hist else ""
        print(f"  {name:50s} avg={r['avg']:.3f} std={r['std']:.3f} med={r['median']:.1f} "
              f"max={r['max']} n={r['rounds']}  {hist_str}")

    # 保存
    output = {
        "timestamp": datetime.now().isoformat(),
        "data_periods": len(draws),
        "backtest_config": {"warmup": 100, "rounds": 500},
        "results": results,
        "top_10": sorted_results[:10],
    }

    output_path = _PROJECT_ROOT / "formula_deep_experiment_v2.json"
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2)

    print(f"\n  结果已保存: {output_path}")


if __name__ == "__main__":
    main()
