# -*- coding: utf-8 -*-
import sys
import time
import logging
from pathlib import Path
from datetime import datetime

# Fix Windows GBK
if sys.stdout.encoding and sys.stdout.encoding.lower() != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8")

_PROJECT_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(_PROJECT_ROOT))

# 日志配置
LOG_DIR = _PROJECT_ROOT / "logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)
LOG_FILE = LOG_DIR / "cloud_runner.log"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.FileHandler(LOG_FILE, encoding="utf-8"), logging.StreamHandler(sys.stdout)],
)
logger = logging.getLogger("CloudRunner")

def run_single_cycle():
    """单轮执行任务"""
    logger.info("--- 开始单轮演算任务 ---")
    try:
        from data_updater_v2 import main as updater_main
        from orchestrate import run_full_pipeline
        
        # 执行更新
        updater_main()
        # 执行预测
        run_full_pipeline(top_k=5)
        logger.info("--- 单轮演算任务执行成功 ---")
    except Exception as e:
        logger.error(f"任务执行失败: {e}")

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--once", action="store_true", help="单次运行")
    args = parser.parse_args()

    # 1. 检查依赖
    try:
        import requests
        import bs4
    except ImportError:
        logger.error("检测到环境缺失！请在终端运行: .\\.venv\\Scripts\\python.exe -m pip install requests beautifulsoup4")
        sys.exit(1)

    # 2. 执行逻辑
    run_single_cycle()