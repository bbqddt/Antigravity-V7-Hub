# -*- coding: utf-8 -*-
"""
公式自主进化引擎 V2.0 — 公平对比版

修正:
1. 公式评估改为"生成多组预测"模式，与传统策略公平对比
2. 增加种群规模和进化代数
3. 引入"多样性惩罚"防止过早收敛到同一公式
4. 每代保留Top-5多样性公式（不只保留最佳）
"""
import json
import random
import sys
from pathlib import Path
from datetime import datetime
from collections import Counter

_PROJECT_ROOT = Path(__file__).resolve().parent
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

from data_layer import load_history, Draw
from formula_lang import get_default_primitives, FormulaGrammar, Primitive
from formula_lang.evaluator import FormulaEvaluator
from formula_lang.mutator import PrimitiveMutator


class FormulaAutonomousEvolutionV2:
    """公式自主进化引擎 V2"""

    def __init__(self, draws, population_size=200, n_generations=30,
                 elite_ratio=0.15, mutation_rate=0.6, crossover_rate=0.5,
                 diversity_penalty=0.05):
        self.draws = draws
        self.population_size = population_size
        self.n_generations = n_generations
        self.elite_ratio = elite_ratio
        self.mutation_rate = mutation_rate
        self.crossover_rate = crossover_rate
        self.diversity_penalty = diversity_penalty
        self.evaluator = FormulaEvaluator()
        self.mutator = PrimitiveMutator()
        self.primitives = get_default_primitives()
        self.population = []  # [(formula, performance), ...]
        self.generation_log = []
        self.best_overall = None
        self.best_overall_perf = None
        self.converged_generations = 0

    def initialize_population(self):
        """初始化种群 — 多样化组合"""
        print(f"\n  初始化种群: {self.population_size} 个公式")
        self.population = []

        for i in range(self.population_size):
            # 多样性: 均匀分配原语组合数
            n_prims = 2 + (i % 5)  # 2-6个原语均匀分布
            if n_prims > len(self.primitives):
                n_prims = len(self.primitives)
            selected = random.sample(self.primitives, n_prims)

            # 多样性: 均匀分配算子
            ops = ['resonance', 'cascade', 'phase_align', 'weighted_sum']
            op = ops[i % len(ops)]

            f = getattr(FormulaGrammar, op)(selected, name=f'gen0_{i}')
            self.population.append((f, None))

        print(f"    种群大小: {len(self.population)}")

    def evaluate_population(self):
        """评估整个种群"""
        formulas = [f for f, _ in self.population]
        results = self.evaluator.evaluate_batch(formulas, self.draws,
                                                 n_windows=10, window_size=500, step=50)

        for i, (f, _) in enumerate(self.population):
            perf = results.get(f.name, results.get(f'gen0_{i}', {}))
            self.population[i] = (f, perf)

    def _diversity_score(self, formula):
        """计算公式的多样性分数（基于原语组合的独特性）"""
        prim_set = frozenset(p.uuid for p in formula.primitives)
        return hash(prim_set) % 10000

    def select_diverse_elites(self):
        """选择精英 — 兼顾性能和多样性"""
        evaluated = [(f, p) for f, p in self.population if p is not None]
        if not evaluated:
            return []

        # 先按稳定分排序
        evaluated.sort(key=lambda x: -(x[1].get('stable', 0) if x[1] else 0))

        n_elites = max(2, int(len(evaluated) * self.elite_ratio))

        # 选择精英，但确保多样性
        elites = [evaluated[0]]
        seen_prim_sets = {frozenset(p.uuid for p in evaluated[0][0].primitives)}

        for f, p in evaluated[1:]:
            if len(elites) >= n_elites:
                break
            prim_set = frozenset(p.uuid for p in f.primitives)
            if prim_set not in seen_prim_sets:
                elites.append((f, p))
                seen_prim_sets.add(prim_set)

        print(f"    精英数量: {len(elites)}/{len(evaluated)}")
        return elites

    def mutate_formula(self, formula):
        """变异公式 — 变异其原语"""
        mutated_prims = []
        for p in formula.primitives:
            if random.random() < self.mutation_rate:
                try:
                    mutated = self.mutator.mutate(p, self.draws, random.Random())
                    mutated_prims.append(mutated)
                except:
                    mutated_prims.append(p)
            else:
                mutated_prims.append(p)

        if not mutated_prims:
            mutated_prims = list(formula.primitives)

        n_prims = max(2, min(6, len(mutated_prims)))
        mutated_prims = mutated_prims[:n_prims]

        op = random.choice(['resonance', 'cascade', 'phase_align', 'weighted_sum'])
        child = getattr(FormulaGrammar, op)(mutated_prims, name=f'mutated_{formula.name}')
        return child

    def crossover_formulas(self, f1, f2):
        """杂交两个公式"""
        n_p1 = random.randint(1, len(f1.primitives))
        n_p2 = random.randint(1, len(f2.primitives))

        children_prims = list(f1.primitives[:n_p1]) + list(f2.primitives[:n_p2])
        children_prims = list(dict.fromkeys(children_prims))  # 去重保序

        if len(children_prims) < 2:
            children_prims = list(f1.primitives) if random.random() < 0.5 else list(f2.primitives)

        children_prims = children_prims[:min(6, len(children_prims))]

        op = random.choice(['resonance', 'cascade', 'phase_align', 'weighted_sum'])
        child = getattr(FormulaGrammar, op)(children_prims, name=f'crossed_{f1.name[:10]}_{f2.name[:10]}')
        return child

    def evolve(self):
        """执行进化"""
        print("\n" + "=" * 70)
        print("  公式自主进化引擎 V2")
        print(f"  种群={self.population_size} 代数={self.n_generations} 精英={self.elite_ratio}")
        print("=" * 70)

        self.initialize_population()

        for gen in range(self.n_generations):
            print(f"\n  ── 第 {gen + 1}/{self.n_generations} 代 ──")

            # 评估
            self.evaluate_population()

            # 排序
            evaluated = [(f, p) for f, p in self.population if p is not None]
            evaluated.sort(key=lambda x: -x[1].get('avg_hits', 0))

            if evaluated:
                best_f, best_p = evaluated[0]
                avg_hits = best_p['avg_hits']
                stable = best_p.get('stable', 0)
                print(f"    最佳: {best_f.name[:40]}")
                print(f"    avg={avg_hits:.4f} std={best_p['std']:.4f} stable={stable:.4f}")

                if self.best_overall is None or avg_hits > self.best_overall_perf.get('avg_hits', 0):
                    self.best_overall = best_f
                    self.best_overall_perf = best_p

            # 记录
            gen_log = {
                "generation": gen + 1,
                "population_size": len(evaluated),
                "best": None,
                "average": None,
                "top5": [],
            }
            if evaluated:
                avg_all = sum(p.get('avg_hits', 0) for _, p in evaluated) / len(evaluated)
                gen_log["average"] = round(avg_all, 4)
                top5 = evaluated[:5]
                gen_log["top5"] = [
                    {"name": f.name[:40], "avg_hits": p.get('avg_hits', 0),
                     "stable": p.get('stable', 0)}
                    for f, p in top5
                ]
                gen_log["best"] = {
                    "name": evaluated[0][0].name[:40],
                    "avg_hits": evaluated[0][1].get('avg_hits', 0),
                    "stable": evaluated[0][1].get('stable', 0),
                }
            self.generation_log.append(gen_log)

            # 选择精英
            elites = self.select_diverse_elites()
            if not elites:
                print("    [WARN] 无存活公式")
                break

            # 生成下一代
            new_population = []

            # 精英保留
            for f, p in elites:
                new_population.append((f, p))

            # 变异
            while len(new_population) < self.population_size:
                parent = random.choice(elites)
                child = self.mutate_formula(parent[0])
                new_population.append((child, None))

            # 杂交
            for _ in range(int(self.population_size * self.crossover_rate)):
                if len(elites) >= 2:
                    p1, p2 = random.sample(elites, 2)
                    child = self.crossover_formulas(p1[0], p2[0])
                    new_population.append((child, None))

            # 补充随机公式
            while len(new_population) < self.population_size:
                n_prims = random.randint(2, min(6, len(self.primitives)))
                selected = random.sample(self.primitives, n_prims)
                op = random.choice(['resonance', 'cascade', 'phase_align', 'weighted_sum'])
                f = getattr(FormulaGrammar, op)(selected, name=f'reseed_{len(new_population)}')
                new_population.append((f, None))

            self.population = new_population

            # 收敛检测
            if gen > 2 and self.generation_log[-1].get('best', {}).get('avg_hits', 0) > 0:
                prev_best = self.generation_log[-2].get('best', {}).get('avg_hits', 0)
                curr_best = self.generation_log[-1]['best']['avg_hits']
                if abs(curr_best - prev_best) < 0.001:
                    self.converged_generations += 1
                else:
                    self.converged_generations = 0

                if self.converged_generations >= 3:
                    print(f"    [收敛] 最佳公式连续{self.converged_generations}代未改善")
                    break

        # 最终评估最佳公式
        print(f"\n{'='*70}")
        print(f"  进化完成")
        print(f"{'='*70}")
        print(f"  总代数: {self.n_generations}")
        if self.best_overall:
            print(f"  最佳公式: {self.best_overall.name[:50]}")
            print(f"  最佳命中: {self.best_overall_perf['avg_hits']:.4f}/6")
            print(f"  最佳稳定: {self.best_overall_perf['stable']:.4f}")
            print(f"  最佳p值:  {self.best_overall_perf.get('p_value', 'N/A')}")

        # 进化轨迹
        if self.generation_log:
            print(f"\n  进化轨迹:")
            for g in self.generation_log:
                if g.get('best'):
                    print(f"    第{g['generation']:2d}代: avg={g['best']['avg_hits']:.4f} stable={g['best']['stable']:.4f}")

        return self._save_results()

    def _save_results(self):
        output = {
            "timestamp": datetime.now().isoformat(),
            "best_formula": {
                "name": self.best_overall.name if self.best_overall else None,
                "primitives": [p.name for p in self.best_overall.primitives] if self.best_overall else [],
                "operators": self.best_overall.operators if self.best_overall else [],
                "performance": self.best_overall_perf,
            },
            "generation_log": self.generation_log,
            "final_population_size": len(self.population),
            "converged_at_generation": self.converged_generations,
        }

        path = _PROJECT_ROOT / "evolution_results_v2.json"
        with open(path, "w", encoding="utf-8") as f:
            json.dump(output, f, ensure_ascii=False, indent=2)

        print(f"\n  结果已保存: evolution_results_v2.json")
        return output


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="公式自主进化引擎 V2")
    parser.add_argument("--generations", type=int, default=25, help="进化代数")
    parser.add_argument("--population", type=int, default=150, help="种群大小")
    parser.add_argument("--elite-ratio", type=float, default=0.15, help="精英比例")
    parser.add_argument("--mutation-rate", type=float, default=0.6, help="变异率")
    parser.add_argument("--crossover-rate", type=float, default=0.5, help="杂交率")
    args = parser.parse_args()

    draws = load_history()
    print(f"数据: {len(draws)} 期 | 原语: {len(get_default_primitives())} 个")

    evolver = FormulaAutonomousEvolutionV2(
        draws,
        population_size=args.population,
        n_generations=args.generations,
        elite_ratio=args.elite_ratio,
        mutation_rate=args.mutation_rate,
        crossover_rate=args.crossover_rate,
    )
    evolver.evolve()
