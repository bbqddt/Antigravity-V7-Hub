# -*- coding: utf-8 -*-
"""
公式实验引擎 V1.0 — 系统性实验所有原语和公式组合

目标：
1. 对每个原语单独做预测，记录命中率
2. 对原语两两组合做共振/级联/相位对齐，记录命中率
3. 找出表现最好的原语组合
4. 输出最优公式用于正式预测
"""
import sys
import json
import random
import numpy as np
from pathlib import Path
from datetime import datetime
from collections import Counter, defaultdict
from itertools import combinations

_PROJECT_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(_PROJECT_ROOT))

from data_layer import load_history
from formula_lang import (
    get_default_primitives, FormulaGrammar, Primitive
)


class FormulaExperimentEngine:
    """公式实验引擎"""

    def __init__(self, draws):
        self.draws = draws
        self.primitives = get_default_primitives()
        self.results = {}
        self.top_combinations = []

    def experiment_single_primitive(self):
        """实验1: 每个原语单独预测"""
        print("\n" + "=" * 70)
        print("  实验1: 单原语预测实验")
        print("=" * 70)

        single_results = {}

        for prim in self.primitives:
            try:
                # 对33个号码打分
                scores = prim.score_all(self.draws)
                # 取top 6
                top6 = sorted(scores.items(), key=lambda x: -x[1])[:6]
                pred_reds = [n for n, s in top6]

                # 用前几期做验证（t-1预测t）
                hits = []
                for i in range(10, min(100, len(self.draws) - 1)):
                    test_draw = self.draws[i - 1]
                    actual_reds = set(test_draw.reds if hasattr(test_draw, 'reds')
                                     else sorted(list(test_draw.red)))

                    # 用前i期训练原语
                    train_draws = self.draws[:i]
                    scores = prim.score_all(train_draws)
                    top6 = sorted(scores.items(), key=lambda x: -x[1])[:6]
                    pred_reds = [n for n, s in top6]

                    hit = len(actual_reds & set(pred_reds))
                    hits.append(hit)

                if hits:
                    avg = np.mean(hits)
                    single_results[prim.name] = {
                        "avg_hits": round(avg, 4),
                        "std": round(float(np.std(hits)), 4),
                        "max_hits": max(hits),
                        "rounds": len(hits),
                        "category": prim.category,
                    }
                    print(f"  {prim.name:30s} avg={avg:.3f} std={np.std(hits):.3f} [{prim.category}]")

            except Exception as e:
                print(f"  {prim.name:30s} ERROR: {e}")

        return single_results

    def experiment_formula_combinations(self):
        """实验2: 原语组合公式"""
        print("\n" + "=" * 70)
        print("  实验2: 原语组合公式实验")
        print("=" * 70)

        combo_results = {}

        # 选出单原语Top-10
        single = self.experiment_single_primitive()
        top_prims = sorted(single.items(), key=lambda x: -x[1]['avg_hits'])[:10]
        print(f"\n  选用Top-10原语做组合实验:")
        for name, r in top_prims:
            print(f"    {name}: avg={r['avg_hits']:.3f}")

        # 用Top-10原语做各种组合
        top_prim_names = [name for name, _ in top_prims]
        top_prims_obj = [p for p in self.primitives if p.name in top_prim_names]

        # 两两组合
        print(f"\n  测试两两组合...")
        for op_name, op_func in [('resonance', FormulaGrammar.resonance),
                                   ('cascade', FormulaGrammar.cascade),
                                   ('phase_align', FormulaGrammar.phase_align),
                                   ('weighted_sum', FormulaGrammar.weighted_sum)]:
            for pair in combinations(top_prims_obj, 2):
                try:
                    formula = op_func(list(pair), name=f'combo_{op_name}_{pair[0].name[:10]}_{pair[1].name[:10]}')
                    hits = []
                    for i in range(50, min(500, len(self.draws) - 1)):
                        test_draw = self.draws[i - 1]
                        actual_reds = set(test_draw.reds if hasattr(test_draw, 'reds')
                                         else sorted(list(test_draw.red)))

                        train_draws = self.draws[:i]
                        top6 = formula.rank_top_6(train_draws)
                        pred_reds = top6[:6]

                        hit = len(actual_reds & set(pred_reds))
                        hits.append(hit)

                    if hits:
                        avg = np.mean(hits)
                        key = f"{op_name}({pair[0].name[:15]},{pair[1].name[:15]})"
                        combo_results[key] = {
                            "avg_hits": round(avg, 4),
                            "std": round(float(np.std(hits)), 4),
                            "rounds": len(hits),
                            "operator": op_name,
                            "primitives": [p.name for p in pair],
                        }
                except Exception as e:
                    pass

        # 排序
        sorted_combos = sorted(combo_results.items(), key=lambda x: -x[1]['avg_hits'])
        print(f"\n  Top-10 组合公式:")
        for name, r in sorted_combos[:10]:
            print(f"    #{name}: avg={r['avg_hits']:.3f} [{r['operator']}]")

        return combo_results

    def experiment_hurst_informed(self):
        """实验3: 基于Hurst指数反持久性的公式"""
        print("\n" + "=" * 70)
        print("  实验3: Hurst反持久性增强公式")
        print("=" * 70)

        # 根据非随机性检测结果，所有位置都是强反持久(H=0.18-0.26)
        # 这意味着均值回归效应极强

        # 创建"反持久性"原语 — 偏好近期未出现的号码
        class MeanReversionPrimitive(Primitive):
            def __init__(self, lookback=100):
                super().__init__(
                    name="mean_reversion",
                    category="temporal",
                    description="均值回归原语 — 近期未出现的号码得分高",
                    parameters={"lookback": lookback},
                )
                self.lookback = lookback

            def score_number(self, n, draws):
                recent = draws[-min(self.lookback, len(draws)):]
                # 计算n的遗漏期数
                omission = 0
                for draw in recent:
                    reds = draw.reds if hasattr(draw, 'reds') else sorted(list(draw.red))
                    if n in reds:
                        omission = 0
                    else:
                        omission += 1

                # 计算n的历史平均出现间隔
                all_positions = []
                for i, draw in enumerate(draws):
                    reds = draw.reds if hasattr(draw, 'reds') else sorted(list(draw.red))
                    if n in reds:
                        all_positions.append(i)

                if len(all_positions) < 2:
                    return 0.5

                avg_gap = np.mean([all_positions[i+1] - all_positions[i]
                                  for i in range(len(all_positions)-1)])

                # 如果当前遗漏 > 平均间隔，说明即将回归
                if avg_gap > 0:
                    score = omission / (avg_gap * 2)
                    return min(score, 1.0)
                return 0.5

        mr_prim = MeanReversionPrimitive()
        print(f"  均值回归原语已创建")

        # 与现有原语组合
        for prim in self.primitives[:5]:
            try:
                formula = FormulaGrammar.resonance([mr_prim, prim],
                                                    name=f'mean_rev_{prim.name}')
                hits = []
                for i in range(50, min(500, len(self.draws) - 1)):
                    test_draw = self.draws[i - 1]
                    actual_reds = set(test_draw.reds if hasattr(test_draw, 'reds')
                                     else sorted(list(test_draw.red)))

                    train_draws = self.draws[:i]
                    top6 = formula.rank_top_6(train_draws)
                    pred_reds = top6[:6]

                    hit = len(actual_reds & set(pred_reds))
                    hits.append(hit)

                if hits:
                    avg = np.mean(hits)
                    print(f"    mean_rev + {prim.name}: avg={avg:.3f} ({len(hits)}轮)")
                    self.results[f'mean_rev_{prim.name}'] = {
                        "avg_hits": round(avg, 4),
                        "rounds": len(hits),
                    }
            except Exception as e:
                pass

        return self.results

    def run_all_experiments(self):
        """运行所有实验"""
        print("\n" + "=" * 70)
        print("  公式实验引擎 — 系统性实验")
        print(f"  数据: {len(self.draws)} 期 | 原语: {len(self.primitives)} 个")
        print("=" * 70)

        # 实验1: 单原语
        single_results = self.experiment_single_primitive()

        # 实验2: 组合公式
        combo_results = self.experiment_formula_combinations()

        # 实验3: Hurst增强
        hurst_results = self.experiment_hurst_informed()

        # 汇总
        print("\n" + "=" * 70)
        print("  实验汇总")
        print("=" * 70)

        all_results = {}
        all_results.update(single_results)
        all_results.update(combo_results)
        all_results.update(hurst_results)

        # 排序
        sorted_results = sorted(all_results.items(), key=lambda x: -x[1].get('avg_hits', 0))

        print(f"\n  Top-20 最佳公式/原语:")
        for i, (name, r) in enumerate(sorted_results[:20]):
            avg = r.get('avg_hits', 0)
            std = r.get('std', 0)
            print(f"    #{i+1:2d} {name:50s} avg={avg:.3f} std={std:.3f}")

        # 保存
        output = {
            "timestamp": datetime.now().isoformat(),
            "data_periods": len(self.draws),
            "n_primitives": len(self.primitives),
            "single_primitive_results": single_results,
            "combo_results": combo_results,
            "hurst_results": hurst_results,
            "top_20": sorted_results[:20],
        }

        output_path = _PROJECT_ROOT / "formula_experiment_results.json"
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(output, f, ensure_ascii=False, indent=2)

        print(f"\n  结果已保存: {output_path}")
        return output


if __name__ == "__main__":
    draws = load_history()
    print(f"加载 {len(draws)} 期数据")

    engine = FormulaExperimentEngine(draws)
    engine.run_all_experiments()
