# -*- coding: utf-8 -*-
"""
公式自主进化引擎 V1.0

核心理念:
- 不是"寻找"公式，而是"开发"公式
- 用存活公式作为种子，变异出下一代
- 每一代都回测，淘汰差的，保留好的
- 让数据自己说话

进化循环:
1. 生成初始公式池（从15个原语 x 4种算子）
2. 评估所有公式
3. 选择Top-20%存活
4. 变异存活公式（参数级 + 逻辑级）
5. 杂交存活公式（交换原语）
6. 重复直到收敛或达到最大代数

用法:
    python formula_autonomous_evolution.py --generations 20 --population 100
"""
import json
import random
import sys
import copy
import math
from pathlib import Path
from datetime import datetime
from collections import Counter

_PROJECT_ROOT = Path(__file__).resolve().parent
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

from data_layer import load_history
from formula_lang import get_default_primitives, FormulaGrammar, Primitive
from formula_lang.evaluator import FormulaEvaluator
from formula_lang.mutator import PrimitiveMutator


class FormulaAutonomousEvolution:
    """公式自主进化引擎"""

    def __init__(self, draws, population_size=100, n_generations=20,
                 elite_ratio=0.2, mutation_rate=0.5, crossover_rate=0.4):
        self.draws = draws
        self.population_size = population_size
        self.n_generations = n_generations
        self.elite_ratio = elite_ratio
        self.mutation_rate = mutation_rate
        self.crossover_rate = crossover_rate
        self.evaluator = FormulaEvaluator()
        self.mutator = PrimitiveMutator()
        self.primitives = get_default_primitives()
        self.population = []  # [(formula, performance), ...]
        self.generation_log = []
        self.best_overall = None
        self.best_overall_perf = None

    def initialize_population(self):
        """初始化种群 — 随机组合原语"""
        print(f"\n  初始化种群: {self.population_size} 个公式")
        self.population = []

        for i in range(self.population_size):
            n_prims = random.randint(2, min(6, len(self.primitives)))
            selected = random.sample(self.primitives, n_prims)
            op = random.choice(['resonance', 'cascade', 'phase_align', 'weighted_sum'])
            f = getattr(FormulaGrammar, op)(selected, name=f'gen0_formula_{i}')
            self.population.append((f, None))  # None = 未评估

        print(f"    种群大小: {len(self.population)}")

    def evaluate_population(self):
        """评估整个种群"""
        formulas = [f for f, _ in self.population]
        results = self.evaluator.evaluate_batch(formulas, self.draws,
                                                 n_windows=10, window_size=500, step=50)

        for i, (f, _) in enumerate(self.population):
            name = f.name
            perf = results.get(name, results.get(f'gen0_formula_{i}', {}))
            self.population[i] = (f, perf)

    def select_elites(self):
        """选择精英"""
        # 过滤掉未评估的
        evaluated = [(f, p) for f, p in self.population if p is not None]
        if not evaluated:
            return []

        # 按稳定分排序
        evaluated.sort(key=lambda x: -(x[1].get('stable', 0) if x[1] else 0))

        n_elites = max(1, int(len(evaluated) * self.elite_ratio))
        elites = evaluated[:n_elites]
        print(f"    精英数量: {n_elites}/{len(evaluated)}")
        return elites

    def mutate_formula(self, formula, draws):
        """变异一个公式 — 变异其原语"""
        mutated_prims = []
        for p in formula.primitives:
            if random.random() < self.mutation_rate:
                try:
                    mutated = self.mutator.mutate(p, draws, random.Random())
                    mutated_prims.append(mutated)
                except:
                    mutated_prims.append(p)
            else:
                mutated_prims.append(p)

        if not mutated_prims:
            mutated_prims = list(formula.primitives)

        # 保持原语数量
        n_prims = max(2, min(6, len(mutated_prims)))
        mutated_prims = mutated_prims[:n_prims]

        new_formula = FormulaGrammar.resonance(mutated_prims,
                                                name=f'mutated_{formula.name}')
        return new_formula

    def crossover_formulas(self, f1, f2):
        """杂交两个公式 — 交换原语子集"""
        # 随机选择f1的部分原语和f2的部分原语
        n_p1 = random.randint(1, len(f1.primitives))
        n_p2 = random.randint(1, len(f2.primitives))

        children_prims = list(f1.primitives[:n_p1]) + list(f2.primitives[:n_p2])
        children_prims = list(set(children_prims))  # 去重

        if len(children_prims) < 2:
            children_prims = list(f1.primitives) if random.random() < 0.5 else list(f2.primitives)

        children_prims = children_prims[:min(6, len(children_prims))]

        op = random.choice(['resonance', 'cascade', 'phase_align', 'weighted_sum'])
        child = getattr(FormulaGrammar, op)(children_prims, name=f'crossed_{f1.name}_{f2.name}')
        return child

    def evolve(self):
        """执行进化"""
        print("\n" + "=" * 70)
        print("  公式自主进化引擎")
        print("=" * 70)

        # 初始化
        self.initialize_population()

        for gen in range(self.n_generations):
            print(f"\n  ── 第 {gen + 1}/{self.n_generations} 代 ──")

            # 1. 评估
            self.evaluate_population()

            # 2. 排序
            evaluated = [(f, p) for f, p in self.population if p is not None]
            evaluated.sort(key=lambda x: -x[1].get('avg_hits', 0))

            if evaluated:
                best_f, best_p = evaluated[0]
                print(f"    最佳公式: {best_f.name}")
                print(f"    avg_hits={best_p['avg_hits']:.4f} std={best_p['std']:.4f} "
                      f"stable={best_p['stable']:.4f} p={best_p['p_value']:.4f}")

                if self.best_overall is None or best_p['avg_hits'] > self.best_overall_perf.get('avg_hits', 0):
                    self.best_overall = best_f
                    self.best_overall_perf = best_p

            # 3. 记录
            gen_log = {
                "generation": gen + 1,
                "population_size": len(evaluated),
                "best": None,
                "average": None,
                "top5": [],
            }
            if evaluated:
                avg_hits = sum(p.get('avg_hits', 0) for _, p in evaluated) / len(evaluated)
                gen_log["average"] = round(avg_hits, 4)

                top5 = evaluated[:5]
                gen_log["top5"] = [
                    {"name": f.name, "avg_hits": p.get('avg_hits', 0),
                     "stable": p.get('stable', 0), "p_value": p.get('p_value', 1)}
                    for f, p in top5
                ]
                gen_log["best"] = {
                    "name": evaluated[0][0].name,
                    "avg_hits": evaluated[0][1].get('avg_hits', 0),
                    "stable": evaluated[0][1].get('stable', 0),
                }
            self.generation_log.append(gen_log)

            # 4. 选择精英
            elites = self.select_elites()
            if not elites:
                print("    [WARN] 无存活公式，退出进化")
                break

            # 5. 生成下一代
            new_population = []

            # 精英保留
            for f, p in elites:
                new_population.append((f, p))

            # 变异
            while len(new_population) < self.population_size:
                parent = random.choice(elites)
                child_formula = self.mutate_formula(parent[0], self.draws)
                new_population.append((child_formula, None))

            # 杂交
            for _ in range(int(self.population_size * self.crossover_rate)):
                if len(elites) >= 2:
                    p1, p2 = random.sample(elites, 2)
                    child = self.crossover_formulas(p1[0], p2[0])
                    new_population.append((child, None))

            # 如果种群不够大，随机生成补充
            while len(new_population) < self.population_size:
                n_prims = random.randint(2, min(6, len(self.primitives)))
                selected = random.sample(self.primitives, n_prims)
                op = random.choice(['resonance', 'cascade', 'phase_align', 'weighted_sum'])
                f = getattr(FormulaGrammar, op)(selected, name=f'reseed_{len(new_population)}')
                new_population.append((f, None))

            self.population = new_population

            # 6. 检查收敛
            if evaluated and len(evaluated) > 10:
                recent_best = evaluated[0][1].get('avg_hits', 0)
                if gen > 3 and self.generation_log[-2].get('best', {}).get('avg_hits', 0) == recent_best:
                    print(f"    [收敛] 最佳公式连续2代未改善")
                    break

        # 最终评估
        print(f"\n{'='*70}")
        print(f"  进化完成")
        print(f"{'='*70}")
        print(f"  总代数: {self.n_generations}")
        print(f"  最佳公式: {self.best_overall.name if self.best_overall else 'N/A'}")
        if self.best_overall_perf:
            print(f"  最佳命中: {self.best_overall_perf['avg_hits']:.4f}/6")
            print(f"  最佳稳定: {self.best_overall_perf['stable']:.4f}")

        return self._save_results()

    def _save_results(self):
        """保存结果"""
        output = {
            "timestamp": datetime.now().isoformat(),
            "best_formula": {
                "name": self.best_overall.name if self.best_overall else None,
                "primitives": [p.uuid for p in self.best_overall.primitives] if self.best_overall else [],
                "performance": self.best_overall_perf,
            },
            "generation_log": self.generation_log,
            "final_population_size": len(self.population),
        }

        path = _PROJECT_ROOT / "evolution_results.json"
        with open(path, "w", encoding="utf-8") as f:
            json.dump(output, f, ensure_ascii=False, indent=2)

        # 保存最佳公式
        if self.best_overall:
            best_path = _PROJECT_ROOT / "best_formula.json"
            with open(best_path, "w", encoding="utf-8") as f:
                json.dump(self.best_overall.to_dict() if hasattr(self.best_overall, 'to_dict') else {
                    "name": self.best_overall.name,
                    "primitives": [p.name for p in self.best_overall.primitives],
                    "operators": self.best_overall.operators,
                    "parameters": self.best_overall.parameters,
                }, f, ensure_ascii=False, indent=2)

        print(f"\n  结果已保存: evolution_results.json")
        return output


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="公式自主进化引擎")
    parser.add_argument("--generations", type=int, default=15, help="进化代数")
    parser.add_argument("--population", type=int, default=80, help="种群大小")
    parser.add_argument("--elite-ratio", type=float, default=0.2, help="精英比例")
    parser.add_argument("--mutation-rate", type=float, default=0.5, help="变异率")
    parser.add_argument("--crossover-rate", type=float, default=0.4, help="杂交率")
    args = parser.parse_args()

    draws = load_history()
    print(f"数据: {len(draws)} 期 | 原语: {len(get_default_primitives())} 个")

    evolver = FormulaAutonomousEvolution(
        draws,
        population_size=args.population,
        n_generations=args.generations,
        elite_ratio=args.elite_ratio,
        mutation_rate=args.mutation_rate,
        crossover_rate=args.crossover_rate,
    )
    evolver.evolve()
