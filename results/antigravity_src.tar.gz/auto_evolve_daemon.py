# -*- coding: utf-8 -*-
"""
Antigravity 持续进化守护进程 V1.0

让系统每小时自动运行一次完整的自主演进循环，永不停止。
同时支持手动触发完整进化。

用法:
    python auto_evolve_daemon.py              # 守护模式（每小时一次）
    python auto_evolve_daemon.py --full       # 单次完整进化
    python auto_evolve_daemon.py --interval 1 # 每1小时运行一次
"""
import sys
import time
import json
import signal
import subprocess
from pathlib import Path
from datetime import datetime

_PROJECT_ROOT = Path(__file__).resolve().parent


class AutoEvolveDaemon:
    """持续进化守护进程"""

    def __init__(self, interval_hours=1):
        self.interval_hours = interval_hours
        self.running = True
        self.cycle_count = 0

        # 注册信号处理
        signal.signal(signal.SIGINT, self._handle_signal)
        signal.signal(signal.SIGTERM, self._handle_signal)

    def _handle_signal(self, signum, frame):
        print(f"\n[守护进程] 收到信号 {signum}，准备退出...")
        self.running = False

    def run_single_cycle(self):
        """运行一次完整的自主演进循环"""
        self.cycle_count += 1
        print(f"\n{'='*70}")
        print(f"  持续进化 — 第 {self.cycle_count} 次循环")
        print(f"  时间: {datetime.now().isoformat()}")
        print(f"{'='*70}")

        start = time.time()

        # 运行智能演进V2
        result = subprocess.run(
            [
                sys.executable, str(_PROJECT_ROOT / "autonomous_evolution_v2.py"),
                "--cycles", "2",
                "--formula-pop", "50",
                "--formula-gen", "3",
            ],
            cwd=str(_PROJECT_ROOT),
            capture_output=False,
            timeout=3600,  # 每轮最多1小时
        )

        elapsed = time.time() - start
        print(f"\n  [守护进程] 本轮耗时: {elapsed:.1f}s")

        # 记录状态
        state = {
            "cycle": self.cycle_count,
            "timestamp": datetime.now().isoformat(),
            "elapsed_seconds": round(elapsed, 2),
            "exit_code": result.returncode,
        }
        with open(_PROJECT_ROOT / "daemon_state.json", "w", encoding="utf-8") as f:
            json.dump(state, f, ensure_ascii=False, indent=2)

        return result.returncode == 0

    def run_forever(self):
        """持续运行"""
        print("=" * 70)
        print("  Antigravity 持续进化守护进程")
        print(f"  运行间隔: {self.interval_hours} 小时")
        print("  按 Ctrl+C 停止")
        print("=" * 70)

        while self.running:
            success = self.run_single_cycle()

            if not success:
                print(f"\n  [守护进程] 本轮失败，等待{self.interval_hours}小时后重试...")

            # 等待下一轮
            wait_seconds = int(self.interval_hours * 3600)
            print(f"\n  [守护进程] 下次进化将在 {self.interval_hours} 小时后启动...")

            for remaining in range(wait_seconds, 0, -60):
                if not self.running:
                    break
                if remaining % 3600 == 0:
                    mins = remaining // 60
                    print(f"    剩余: {mins} 分钟")
                time.sleep(60)

        print(f"\n  [守护进程] 已停止。共运行 {self.cycle_count} 次循环。")


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Antigravity 持续进化守护进程")
    parser.add_argument("--full", action="store_true", help="单次完整进化")
    parser.add_argument("--interval", type=float, default=1.0, help="运行间隔（小时）")
    args = parser.parse_args()

    daemon = AutoEvolveDaemon(interval_hours=args.interval)

    if args.full:
        daemon.run_single_cycle()
    else:
        daemon.run_forever()
