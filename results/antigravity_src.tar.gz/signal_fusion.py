# -*- coding: utf-8 -*-
"""
Antigravity 信号融合层 V1.0

将非随机性检测器输出的 position_prior.json 转化为可操作的预测信号。

核心发现 (V2.2 检测器输出):
1. 所有位置 Hurst 指数 < 0.3 → 强反持久性 (均值回归)
2. 蓝球 Hurst = 0.18 → 最强的均值回归信号
3. 游程检验在位置4、6显著偏离 → 这些位置的号码交替模式异常
4. 频谱检测到多个周期信号 (28期、50期、84期)

策略:
- 蓝球: 均值回归优先 (遗漏策略 + Hurst 方向校正)
- 红球: 反持久性号码优先 (出现后倾向于不再出现 → 选遗漏号)
- 周期性: 在28/50/84期附近的开奖中，对特定位置号码加权
"""
import json
import os
from pathlib import Path
from typing import Dict, Optional

_PROJECT_ROOT = Path(__file__).resolve().parent
_POSITION_PRIOR_PATH = _PROJECT_ROOT / "position_prior.json"


def load_position_prior() -> Dict:
    """加载结构化位置先验"""
    if _POSITION_PRIOR_PATH.exists():
        with open(_POSITION_PRIOR_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}


def get_hurst_bias(position_prior: Optional[Dict] = None) -> Dict[str, float]:
    """
    获取每个位置的 Hurst 偏差。

    Returns:
        {"1": -0.24, "2": -0.26, ..., "blue": -0.32}
        负值 = 反持久性 (均值回归)
        正值 = 持久性 (趋势延续)
    """
    if position_prior is None:
        position_prior = load_position_prior()

    deviations = position_prior.get("position_deviations", {})
    result = {}
    for pos, metrics in deviations.items():
        hurst_dev = metrics.get("hurst_dev", 0.0)
        # Hurst < 0.5 表示反持久性，deviation = 0.5 - H
        # 返回 -deviation 以便直接使用: -0.24 表示均值回归强度
        result[pos] = -hurst_dev
    return result


def get_mean_reversion_signal(position_prior: Optional[Dict] = None) -> Dict[str, bool]:
    """
    获取均值回归信号：True 表示该位置有强均值回归倾向。

    阈值: |H - 0.5| > 0.15 视为显著。
    """
    hurst_bias = get_hurst_bias(position_prior)
    return {pos: abs(bias) > 0.15 for pos, bias in hurst_bias.items()}


def get_periodic_signals(position_prior: Optional[Dict] = None) -> Dict[str, list]:
    """
    获取频谱周期信号。

    Returns:
        {"1": [28, 42], "2": [111, 87], ...}
        每个位置的显著周期（期数）
    """
    if position_prior is None:
        position_prior = load_position_prior()

    deviations = position_prior.get("position_deviations", {})
    result = {}
    for pos, metrics in deviations.items():
        peaks = metrics.get("spectral_peaks", 0)
        if peaks > 1000:  # 频谱峰值很大 → 有周期信号
            result[pos] = [int(peaks)]  # 简化: 取最强周期
    return result


def get_runs_anomalies(position_prior: Optional[Dict] = None) -> list:
    """
    获取游程检验异常的位置。

    Returns:
        [{"position": 6, "z": 1.29, "direction": "too_many_runs"}, ...]
    """
    if position_prior is None:
        position_prior = load_position_prior()

    deviations = position_prior.get("position_deviations", {})
    anomalies = []
    for pos, metrics in deviations.items():
        runs_z = metrics.get("runs_z", 0)
        if abs(runs_z) > 0.5:  # |z| > 0.5 视为异常
            direction = "too_many_runs" if runs_z > 0 else "too_few_runs"
            anomalies.append({
                "position": pos,
                "z": round(runs_z, 3),
                "direction": direction,
            })
    return anomalies


def apply_hurst_correction_to_omission(df, position_prior: Optional[Dict] = None):
    """
    对遗漏策略施加 Hurst 方向校正。

    原理: 如果蓝球 Hurst = 0.18 (强反持久性)，
    则遗漏策略应优先选择"遗漏期数接近 Hurst 预测均值回归点"的号码。

    简单实现: 如果 Hurst < 0.3，遗漏策略的权重加倍。
    """
    hurst_bias = get_hurst_bias(position_prior)
    blue_hurst = hurst_bias.get("blue", 0)

    if blue_hurst < -0.2:  # 强反持久性
        # 遗漏策略权重加倍
        return 2.0
    elif blue_hurst < -0.1:  # 中等反持久性
        return 1.5
    else:
        return 1.0  # 无信号，正常权重


def apply_positional_bias_to_reds(draws, position_prior: Optional[Dict] = None):
    """
    对红球位置序列施加均值回归偏置。

    原理: 如果位置 i 的 Hurst = 0.24 (强反持久性)，
    则该位置的号码倾向于回到历史均值。
    我们可以计算每个位置的长期均值，然后偏好接近均值的号码。
    """
    if position_prior is None:
        position_prior = load_position_prior()

    deviations = position_prior.get("position_deviations", {})
    hurst_bias = {pos: -metrics.get("hurst_dev", 0) for pos, metrics in deviations.items()
                  if pos != "blue" and "hurst_dev" in metrics}

    # 计算每个位置的长期均值
    pos_means = {}
    for i in range(1, 7):
        pos_key = str(i)
        if pos_key not in hurst_bias:
            continue
        values = []
        for d in draws[-200:]:  # 最近200期
            reds = sorted(d.red) if hasattr(d, 'red') else sorted(list(d.red))
            if i <= len(reds):
                values.append(reds[i - 1])
        if values:
            pos_means[i] = {
                "mean": sum(values) / len(values),
                "hurst_bias": hurst_bias[pos_key],
            }

    return pos_means


def summarize_signals(position_prior: Optional[Dict] = None) -> str:
    """生成人类可读的信号摘要"""
    if position_prior is None:
        position_prior = load_position_prior()

    hurst_bias = get_hurst_bias(position_prior)
    mean_rev = get_mean_reversion_signal(position_prior)
    anomalies = get_runs_anomalies(position_prior)
    periodic = get_periodic_signals(position_prior)

    lines = ["=== Antigravity 信号摘要 ==="]

    # Hurst 信号
    blue_hurst = hurst_bias.get("blue", 0)
    lines.append(f"\n🔮 蓝球 Hurst: {blue_hurst:.4f} → {'强均值回归' if blue_hurst < -0.2 else '中等均值回归' if blue_hurst < -0.1 else '无显著信号'}")

    for pos in range(1, 7):
        bias = hurst_bias.get(str(pos), 0)
        strength = "强" if abs(bias) > 0.2 else "中" if abs(bias) > 0.1 else "弱"
        direction = "均值回归" if bias < 0 else "趋势延续"
        lines.append(f"  位置{pos} Hurst: {bias:.4f} ({strength}{direction})")

    # 游程异常
    if anomalies:
        lines.append(f"\n📊 游程异常 ({len(anomalies)}个位置):")
        for a in anomalies:
            lines.append(f"  位置{a['position']}: z={a['z']:.3f} → {a['direction']}")

    # 周期信号
    if periodic:
        lines.append(f"\n🔄 周期信号 ({len(periodic)}个位置有显著周期):")
        for pos, cycles in periodic.items():
            lines.append(f"  位置{pos}: 周期≈{cycles[0]}期")

    # 测试一致性
    agreement = position_prior.get("test_agreement", {})
    consistent_tests = sum(1 for v in agreement.values() if v)
    lines.append(f"\n✅ 测试一致性: {consistent_tests}/4 组测试一致")

    return "\n".join(lines)


if __name__ == "__main__":
    prior = load_position_prior()
    print(summarize_signals(prior))
