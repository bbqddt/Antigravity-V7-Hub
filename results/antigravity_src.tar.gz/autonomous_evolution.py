# -*- coding: utf-8 -*-
"""
Antigravity 自主演进循环 V0.1

理念:
- 不预设方向
- 不选择"最好的"方法
- 而是同时运行所有方法，让数据自己说话
- 每一轮都生成新的检验、新的公式、新的假设
- 存活超过3轮的信号 = 可能是结构
- 只存活1轮的信号 = 可能是涨落

这就是你说的"不断尝试，找到比较好的再深挖"。
"""
import json
import os
import subprocess
import sys
from pathlib import Path
from datetime import datetime

_PROJECT_ROOT = Path(__file__).resolve().parent

# 所有可用的探测器/检验/公式
MODULES = [
    "nonrandomness_detector.py",      # 22项非随机性检验
    "time_nonexistence_test.py",       # 8项时间存在性检验
    "formula_discovery.py",            # 100K公式暴力搜索
    "formula_evolver.py",              # 公式进化器
    "number_attributes.py",            # 号码多维属性分析
    "signal_fusion.py",                # 信号融合层
    "walkforward_backtest_v2.py",      # 回测框架
    "orchestrate.py",                  # 统一编排
    # 新支柱: 公式开发生态
    "formula_development_orchestrator.py",  # 公式开发总控 (三支柱合一)
]


class AutonomousLoop:
    def __init__(self, max_cycles=100):
        self.max_cycles = max_cycles
        self.signal_log = []  # 所有发现的信号
        self.cycle = 0

    def run(self):
        print("=" * 70)
        print("  🔄 Antigravity 自主演进循环 V0.1")
        print("  不预设方向，让数据自己说话")
        print("=" * 70)
        print()

        for cycle in range(1, self.max_cycles + 1):
            self.cycle = cycle
            print(f"\n{'='*60}")
            print(f"  周期 {cycle}/{self.max_cycles}")
            print(f"{'='*60}")

            # 1. 运行所有探测器
            signals = self._run_all_modules()

            # 2. 记录新信号
            self._record_signals(signals)

            # 3. 检查是否有信号存活超过3轮
            persistent = self._find_persistent_signals()
            if persistent:
                print(f"\n  🔥 存活信号 ({len(persistent)}个):")
                for s in persistent[:5]:
                    print(f"    - {s}")

            # 4. 保存状态
            self._save_state()

            # 5. 暂停一下（如果需要）
            # break  # 取消注释以只跑一轮

        print(f"\n✅ 自主演进循环完成: {self.max_cycles} 周期")
        print(f"   发现信号总数: {len(self.signal_log)}")

    def _run_all_modules(self):
        """运行所有模块，收集信号"""
        signals = []

        for module in MODULES:
            filepath = _PROJECT_ROOT / module
            if not filepath.exists():
                continue

            try:
                result = subprocess.run(
                    [sys.executable, str(filepath)],
                    capture_output=True,
                    text=True,
                    encoding="utf-8",
                    timeout=300,
                    cwd=str(_PROJECT_ROOT),
                )

                # 从输出中提取信号关键词
                output = result.stdout + result.stderr
                signal_keywords = [
                    "证伪", "通过", "偏离", "命中", "fitness",
                    "Hurst", "KS", "ACF", "MI", "entropy",
                    "存活", "最佳公式", "Top-",
                ]

                for kw in signal_keywords:
                    if kw in output:
                        lines = [l.strip() for l in output.split('\n') if kw in l]
                        for line in lines[:3]:  # 最多取3行
                            signals.append({
                                "module": module,
                                "cycle": self.cycle,
                                "keyword": kw,
                                "signal": line[:200],
                            })

            except subprocess.TimeoutExpired:
                print(f"  [WARN] {module} 超时")
            except Exception as e:
                print(f"  [ERROR] {module}: {e}")

        return signals

    def _record_signals(self, signals):
        """记录新发现的信号"""
        for s in signals:
            # 去重：同一模块同一周期的相同关键词只记一次
            key = f"{s['module']}:{s['cycle']}:{s['keyword']}"
            if not any(sig["key"] == key for sig in self.signal_log):
                s["key"] = key
                self.signal_log.append(s)

    def _find_persistent_signals(self):
        """查找存活超过3轮的信号"""
        from collections import Counter
        keywords = Counter()
        for s in self.signal_log:
            keywords[s["keyword"]] += 1

        persistent = [kw for kw, count in keywords.items() if count >= 3]
        return persistent

    def _save_state(self):
        """保存状态"""
        state = {
            "cycle": self.cycle,
            "total_signals": len(self.signal_log),
            "persistent_signals": self._find_persistent_signals(),
            "last_run": datetime.now().isoformat(),
        }
        with open(str(_PROJECT_ROOT / "evolution_state.json"), "w", encoding="utf-8") as f:
            json.dump(state, f, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Antigravity 自主演进循环")
    parser.add_argument("--daemon", action="store_true", help="守护模式")
    parser.add_argument("--cycles", type=int, default=100, help="运行周期数")
    parser.add_argument("--once", action="store_true", help="单次运行")
    args = parser.parse_args()

    loop = AutonomousLoop(max_cycles=args.cycles if not args.once else 1)
    loop.run()
